# 📱 Reading Tracker - Полная инструкция по установке

## 🎯 Что это?

Полный проект мобильного приложения **Reading Tracker** на React Native + Expo для отслеживания чтения книг.

---

## 📋 Требования

Перед началом установите:

1. **Node.js** (версия 18 или выше)
   - Скачать: https://nodejs.org/
   - Проверка: `node --version`

2. **npm** или **yarn**
   - npm идёт с Node.js
   - yarn: `npm install -g yarn`

3. **Expo CLI** (опционально)
   - `npm install -g expo-cli`

4. **Приложение Expo Go** на телефоне
   - iOS: App Store
   - Android: Google Play

---

## 🚀 Быстрый старт (3 шага)

### Шаг 1: Создайте новый проект Expo

```bash
npx create-expo-app reading-tracker --template blank-typescript
cd reading-tracker
```

### Шаг 2: Скопируйте файлы проекта

Скопируйте все файлы из архива в папку `reading-tracker`, заменив существующие:

```
reading-tracker/
├── app/
│   ├── (tabs)/
│   │   ├── index.tsx         ← Главный экран
│   │   ├── search.tsx        ← Поиск
│   │   ├── settings.tsx      ← Настройки
│   │   └── statistics.tsx    ← Статистика
│   └── _layout.tsx           ← Корневой layout
├── components/
│   ├── book-card.tsx
│   ├── book-detail-modal.tsx
│   ├── edit-book-modal.tsx
│   ├── edit-note-modal.tsx
│   ├── add-book-modal.tsx
│   ├── image-picker-modal.tsx
│   ├── icon-symbol.tsx
│   └── screen-container.tsx
├── lib/
│   ├── storage.ts
│   ├── book-context.tsx
│   ├── statistics.ts
│   ├── notifications.ts
│   └── image-picker.ts
├── hooks/
│   ├── use-colors.ts
│   └── use-color-scheme.ts
├── app.json
├── package.json
├── tsconfig.json
├── tailwind.config.js
├── babel.config.js
└── metro.config.js
```

### Шаг 3: Установите зависимости и запустите

```bash
# Установка зависимостей
npm install

# Запуск приложения
npm start
```

Отсканируйте QR-код в приложении Expo Go!

---

## 📦 Установка зависимостей (детально)

Если у вас проблемы с установкой, установите пакеты по отдельности:

```bash
# Основные зависимости
npm install expo@~51.0.28
npm install expo-router@~3.5.23
npm install react@18.2.0
npm install react-native@0.74.5

# Навигация и UI
npm install @react-navigation/native@^6.1.9
npm install react-native-safe-area-context@4.10.5
npm install react-native-screens@3.31.1

# Хранилище данных
npm install @react-native-async-storage/async-storage@1.23.1

# Файловая система и уведомления
npm install expo-file-system@~17.0.1
npm install expo-notifications@~0.28.16
npm install expo-image-picker@~15.0.7

# Стилизация (NativeWind/Tailwind)
npm install nativewind@^2.0.11
npm install tailwindcss@3.3.2

# Утилиты Expo
npm install expo-constants@~16.0.2
npm install expo-linking@~6.3.1
npm install expo-splash-screen@~0.27.5
npm install expo-status-bar@~1.12.1

# TypeScript и DevDependencies
npm install --save-dev typescript@~5.3.3
npm install --save-dev @types/react@~18.2.45
npm install --save-dev @babel/core@^7.20.0
npm install --save-dev jest@^29.7.0
npm install --save-dev jest-expo@~51.0.3
```

---

## 🔧 Альтернативный метод (если проблемы с Expo)

### Вариант A: Использовать только нужные файлы

Создайте новый Expo проект и скопируйте только:
1. `app/` - все экраны
2. `components/` - все компоненты
3. `lib/` - бизнес-логика
4. `hooks/` - хуки

Затем вручную установите зависимости из `package.json`.

### Вариант B: React Native CLI (без Expo)

```bash
npx react-native init ReadingTracker --template react-native-template-typescript
cd ReadingTracker

# Установите необходимые пакеты
npm install @react-navigation/native @react-navigation/bottom-tabs
npm install @react-native-async-storage/async-storage
npm install react-native-screens react-native-safe-area-context
```

Адаптируйте код, убрав зависимости от Expo.

---

## 📱 Структура проекта

```
reading-tracker/
│
├── 📱 app/                    # Screens (Expo Router)
│   ├── (tabs)/               # Tab Navigation
│   │   ├── index.tsx         # Library Screen
│   │   ├── search.tsx        # Search Screen
│   │   ├── settings.tsx      # Settings Screen
│   │   └── statistics.tsx    # Statistics Screen
│   └── _layout.tsx           # Root Layout
│
├── 🧩 components/            # Reusable Components
│   ├── book-card.tsx         # Book Card
│   ├── book-detail-modal.tsx # Book Detail Modal
│   ├── edit-book-modal.tsx   # Edit Book Modal ✨
│   ├── edit-note-modal.tsx   # Edit Note Modal ✨
│   ├── add-book-modal.tsx    # Add Book Modal
│   ├── image-picker-modal.tsx# Image Picker
│   ├── icon-symbol.tsx       # Icon Component
│   └── screen-container.tsx  # Screen Wrapper
│
├── 📚 lib/                   # Business Logic
│   ├── storage.ts            # AsyncStorage wrapper
│   ├── book-context.tsx      # State Management
│   ├── statistics.ts         # Stats calculations
│   ├── notifications.ts      # Notifications
│   └── image-picker.ts       # Image handling
│
├── 🪝 hooks/                 # Custom Hooks
│   ├── use-colors.ts         # Theme colors
│   └── use-color-scheme.ts   # Dark/Light mode
│
├── ⚙️ Configuration
│   ├── app.json              # Expo config
│   ├── package.json          # Dependencies
│   ├── tsconfig.json         # TypeScript
│   ├── tailwind.config.js    # Tailwind CSS
│   ├── babel.config.js       # Babel
│   └── metro.config.js       # Metro bundler
│
└── 📄 Documentation
    ├── README.md             # Full documentation
    ├── CHANGELOG.md          # Version history
    ├── QUICKSTART.md         # Quick guide (RU)
    └── INSTALLATION.md       # This file
```

---

## 🎨 Функции приложения

### ✅ Реализовано (v1.1.0)

- ✅ Библиотека книг с группировкой по статусу
- ✅ Добавление книг с деталями
- ✅ Отслеживание прогресса чтения
- ✅ Личные заметки к книгам
- ✅ **Редактирование книг** (NEW!)
- ✅ **Редактирование заметок** (NEW!)
- ✅ Поиск и фильтрация
- ✅ Статистика чтения
- ✅ Экспорт/импорт данных
- ✅ Уведомления о чтении
- ✅ Тёмная/светлая тема

### 🚧 Планируется

- ⏳ Полноценная загрузка обложек
- ⏳ Тактильная обратная связь
- ⏳ Шеринг книг
- ⏳ Графики и визуализация

---

## 🐛 Решение проблем

### Проблема: Ошибка при установке зависимостей

**Решение:**
```bash
# Очистите кеш
npm cache clean --force
rm -rf node_modules package-lock.json

# Переустановите
npm install
```

### Проблема: "Metro bundler error"

**Решение:**
```bash
# Очистите Metro cache
npx expo start --clear
```

### Проблема: "TypeScript errors"

**Решение:**
```bash
# Проверьте tsconfig.json
# Убедитесь что все импорты правильные
# Перезапустите TypeScript сервер в IDE
```

### Проблема: Не работает NativeWind/Tailwind

**Решение:**
1. Убедитесь что `babel.config.js` содержит `nativewind/babel`
2. Перезапустите Metro: `npx expo start --clear`
3. Проверьте `tailwind.config.js`

### Проблема: AsyncStorage ошибки

**Решение:**
```bash
# Переустановите
npm uninstall @react-native-async-storage/async-storage
npm install @react-native-async-storage/async-storage@1.23.1

# Для iOS
cd ios && pod install && cd ..
```

---

## 📱 Запуск на устройстве

### iOS (нужен Mac)

```bash
npm run ios
```

Или через Xcode:
1. Откройте `ios/ReadingTracker.xcworkspace`
2. Выберите устройство
3. Нажмите Run

### Android

```bash
npm run android
```

Или:
1. Откройте Android Studio
2. Импортируйте папку `android/`
3. Запустите

### Web (для тестирования)

```bash
npm run web
```

---

## 🔑 Ключевые файлы для настройки

### 1. Цветовая схема
`hooks/use-colors.ts` - измените цвета приложения

### 2. Конфигурация
`app.json` - название, иконка, splash screen

### 3. Навигация
`app/_layout.tsx` - структура навигации

### 4. Хранилище
`lib/storage.ts` - логика сохранения данных

---

## 📞 Поддержка

Если возникли проблемы:

1. Проверьте [CHANGELOG.md](CHANGELOG.md) - известные проблемы
2. Проверьте [README.md](README.md) - полная документация
3. Проверьте [QUICKSTART.md](QUICKSTART.md) - быстрый старт

---

## 🎓 Полезные ссылки

- [Expo Documentation](https://docs.expo.dev/)
- [React Native Documentation](https://reactnative.dev/)
- [React Navigation](https://reactnavigation.org/)
- [NativeWind](https://www.nativewind.dev/)
- [AsyncStorage](https://react-native-async-storage.github.io/async-storage/)

---

## ✅ Чеклист готовности

Перед запуском убедитесь:

- [ ] Node.js установлен (v18+)
- [ ] Все зависимости установлены (`npm install`)
- [ ] Нет ошибок TypeScript
- [ ] Metro bundler запускается
- [ ] Expo Go установлен на телефоне
- [ ] Проект запускается (`npm start`)

---

## 🎉 Готово!

После успешной установки вы сможете:

1. ✅ Добавлять книги в библиотеку
2. ✅ Отслеживать прогресс чтения
3. ✅ Редактировать книги и заметки
4. ✅ Просматривать статистику
5. ✅ Экспортировать/импортировать данные

**Приятного чтения! 📚✨**

---

**Версия**: 1.1.0  
**Дата**: Январь 2026  
**Статус**: Готово к использованию ✅
