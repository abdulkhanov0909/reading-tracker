import { Stack } from 'expo-router';
import { BookProvider } from '@/lib/book-context';
import { SafeAreaProvider } from 'react-native-safe-area-context';

export default function RootLayout() {
  return (
    <SafeAreaProvider>
      <BookProvider>
        <Stack screenOptions={{ headerShown: false }}>
          <Stack.Screen name="(tabs)" />
        </Stack>
      </BookProvider>
    </SafeAreaProvider>
  );
}
