import AsyncStorage from '@react-native-async-storage/async-storage';

export interface Note {
  id: string;
  bookId: string;
  text: string;
  createdAt: number;
}

export interface Book {
  id: string;
  title: string;
  author: string;
  isbn?: string;
  totalPages: number;
  currentPage: number;
  status: 'want-to-read' | 'reading' | 'completed';
  coverImage?: string;
  coverImageUri?: string;
  startDate?: number;
  targetDate?: number;
  completedDate?: number;
  createdAt: number;
  updatedAt: number;
}

const BOOKS_KEY = '@reading_tracker_books';
const NOTES_KEY = '@reading_tracker_notes';

export const storage = {
  // Books operations
  async getBooks(): Promise<Book[]> {
    try {
      const data = await AsyncStorage.getItem(BOOKS_KEY);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error('Error reading books:', error);
      return [];
    }
  },

  async addBook(book: Omit<Book, 'id' | 'createdAt' | 'updatedAt'>): Promise<Book> {
    const books = await this.getBooks();
    const newBook: Book = {
      ...book,
      id: `book_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    books.push(newBook);
    await AsyncStorage.setItem(BOOKS_KEY, JSON.stringify(books));
    return newBook;
  },

  async updateBook(id: string, updates: Partial<Book>): Promise<Book | null> {
    const books = await this.getBooks();
    const index = books.findIndex((b) => b.id === id);
    if (index === -1) return null;
    
    const updatedBook = {
      ...books[index],
      ...updates,
      id: books[index].id,
      createdAt: books[index].createdAt,
      updatedAt: Date.now(),
    };
    books[index] = updatedBook;
    await AsyncStorage.setItem(BOOKS_KEY, JSON.stringify(books));
    return updatedBook;
  },

  async deleteBook(id: string): Promise<boolean> {
    const books = await this.getBooks();
    const filtered = books.filter((b) => b.id !== id);
    if (filtered.length === books.length) return false;
    
    await AsyncStorage.setItem(BOOKS_KEY, JSON.stringify(filtered));
    // Also delete associated notes
    await this.deleteNotesByBookId(id);
    return true;
  },

  async getBook(id: string): Promise<Book | null> {
    const books = await this.getBooks();
    return books.find((b) => b.id === id) || null;
  },

  // Notes operations
  async getNotes(bookId: string): Promise<Note[]> {
    try {
      const data = await AsyncStorage.getItem(NOTES_KEY);
      const allNotes: Note[] = data ? JSON.parse(data) : [];
      return allNotes.filter((n) => n.bookId === bookId);
    } catch (error) {
      console.error('Error reading notes:', error);
      return [];
    }
  },

  async addNote(bookId: string, text: string): Promise<Note> {
    const allNotes = await this.getAllNotes();
    const newNote: Note = {
      id: `note_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      bookId,
      text,
      createdAt: Date.now(),
    };
    allNotes.push(newNote);
    await AsyncStorage.setItem(NOTES_KEY, JSON.stringify(allNotes));
    return newNote;
  },

  async updateNote(id: string, text: string): Promise<Note | null> {
    const allNotes = await this.getAllNotes();
    const index = allNotes.findIndex((n) => n.id === id);
    if (index === -1) return null;
    
    allNotes[index].text = text;
    await AsyncStorage.setItem(NOTES_KEY, JSON.stringify(allNotes));
    return allNotes[index];
  },

  async deleteNote(id: string): Promise<boolean> {
    const allNotes = await this.getAllNotes();
    const filtered = allNotes.filter((n) => n.id !== id);
    if (filtered.length === allNotes.length) return false;
    
    await AsyncStorage.setItem(NOTES_KEY, JSON.stringify(filtered));
    return true;
  },

  async getAllNotes(): Promise<Note[]> {
    try {
      const data = await AsyncStorage.getItem(NOTES_KEY);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error('Error reading all notes:', error);
      return [];
    }
  },

  async deleteNotesByBookId(bookId: string): Promise<void> {
    const allNotes = await this.getAllNotes();
    const filtered = allNotes.filter((n) => n.bookId !== bookId);
    await AsyncStorage.setItem(NOTES_KEY, JSON.stringify(filtered));
  },

  // Export/Import
  async exportData(): Promise<{ books: Book[]; notes: Note[] }> {
    const books = await this.getBooks();
    const notes = await this.getAllNotes();
    return { books, notes };
  },

  async importData(data: { books: Book[]; notes: Note[] }): Promise<void> {
    await AsyncStorage.setItem(BOOKS_KEY, JSON.stringify(data.books));
    await AsyncStorage.setItem(NOTES_KEY, JSON.stringify(data.notes));
  },

  async clearAllData(): Promise<void> {
    await AsyncStorage.removeItem(BOOKS_KEY);
    await AsyncStorage.removeItem(NOTES_KEY);
  },
};
