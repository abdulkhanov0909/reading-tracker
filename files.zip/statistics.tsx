import React, { useMemo } from 'react';
import { ScrollView, Text, View } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { useBooks } from '@/lib/book-context';
import { calculateReadingStats, calculateReadingGoals, getReadingTrends } from '@/lib/statistics';
import { useColors } from '@/hooks/use-colors';

export default function StatisticsScreen() {
  const colors = useColors();
  const { books } = useBooks();

  const stats = useMemo(() => calculateReadingStats(books), [books]);
  const goals = useMemo(() => calculateReadingGoals(books), [books]);
  const trends = useMemo(() => getReadingTrends(books, 30), [books]);

  const weeklyProgressPercent = (goals.weeklyProgress / goals.weeklyGoal) * 100;
  const monthlyProgressPercent = (goals.monthlyProgress / goals.monthlyGoal) * 100;

  return (
    <ScreenContainer className="p-0">
      {/* Header */}
      <View className="bg-surface border-b border-border px-4 py-3">
        <Text className="text-2xl font-bold text-foreground">Reading Stats</Text>
      </View>

      {/* Content */}
      <ScrollView className="flex-1 px-4 py-4">
        {/* Main Stats Grid */}
        <View className="gap-3 mb-6">
          {/* Top Row */}
          <View className="flex-row gap-3">
            <View className="flex-1 bg-surface rounded-lg p-4 border border-border">
              <Text className="text-xs text-muted mb-1 font-medium">Books Read</Text>
              <Text className="text-3xl font-bold text-primary">{stats.totalBooksRead}</Text>
              <Text className="text-xs text-muted mt-1">all time</Text>
            </View>

            <View className="flex-1 bg-surface rounded-lg p-4 border border-border">
              <Text className="text-xs text-muted mb-1 font-medium">Pages Read</Text>
              <Text className="text-3xl font-bold text-primary">{stats.totalPagesRead}</Text>
              <Text className="text-xs text-muted mt-1">total</Text>
            </View>
          </View>

          {/* Second Row */}
          <View className="flex-row gap-3">
            <View className="flex-1 bg-surface rounded-lg p-4 border border-border">
              <Text className="text-xs text-muted mb-1 font-medium">Avg Pages/Day</Text>
              <Text className="text-3xl font-bold text-warning">{stats.averagePagesPerDay}</Text>
              <Text className="text-xs text-muted mt-1">reading pace</Text>
            </View>

            <View className="flex-1 bg-surface rounded-lg p-4 border border-border">
              <Text className="text-xs text-muted mb-1 font-medium">Current Streak</Text>
              <Text className="text-3xl font-bold text-success">{stats.currentStreak}</Text>
              <Text className="text-xs text-muted mt-1">days</Text>
            </View>
          </View>

          {/* Third Row */}
          <View className="flex-row gap-3">
            <View className="flex-1 bg-surface rounded-lg p-4 border border-border">
              <Text className="text-xs text-muted mb-1 font-medium">Longest Streak</Text>
              <Text className="text-3xl font-bold text-success">{stats.longestStreak}</Text>
              <Text className="text-xs text-muted mt-1">days</Text>
            </View>

            <View className="flex-1 bg-surface rounded-lg p-4 border border-border">
              <Text className="text-xs text-muted mb-1 font-medium">In Progress</Text>
              <Text className="text-3xl font-bold text-warning">{stats.booksInProgress}</Text>
              <Text className="text-xs text-muted mt-1">books</Text>
            </View>
          </View>
        </View>

        {/* Reading Goals */}
        <View className="mb-6">
          <Text className="text-lg font-bold text-foreground mb-3">Reading Goals</Text>

          {/* Weekly Goal */}
          <View className="bg-surface rounded-lg p-4 border border-border mb-3">
            <View className="flex-row justify-between items-center mb-2">
              <Text className="text-sm font-semibold text-foreground">This Week</Text>
              <Text className="text-sm font-medium text-primary">
                {goals.weeklyProgress}/{goals.weeklyGoal} books
              </Text>
            </View>
            <View className="h-2 bg-border rounded-full overflow-hidden">
              <View
                className="h-full bg-primary rounded-full"
                style={{ width: `${Math.min(weeklyProgressPercent, 100)}%` }}
              />
            </View>
            <Text className="text-xs text-muted mt-2">
              {weeklyProgressPercent >= 100
                ? '✓ Goal reached!'
                : `${Math.round(weeklyProgressPercent)}% complete`}
            </Text>
          </View>

          {/* Monthly Goal */}
          <View className="bg-surface rounded-lg p-4 border border-border">
            <View className="flex-row justify-between items-center mb-2">
              <Text className="text-sm font-semibold text-foreground">This Month</Text>
              <Text className="text-sm font-medium text-primary">
                {goals.monthlyProgress}/{goals.monthlyGoal} books
              </Text>
            </View>
            <View className="h-2 bg-border rounded-full overflow-hidden">
              <View
                className="h-full bg-primary rounded-full"
                style={{ width: `${Math.min(monthlyProgressPercent, 100)}%` }}
              />
            </View>
            <Text className="text-xs text-muted mt-2">
              {monthlyProgressPercent >= 100
                ? '✓ Goal reached!'
                : `${Math.round(monthlyProgressPercent)}% complete`}
            </Text>
          </View>
        </View>

        {/* Reading Insights */}
        <View className="mb-6">
          <Text className="text-lg font-bold text-foreground mb-3">Reading Insights</Text>

          <View className="bg-surface rounded-lg p-4 border border-border gap-3">
            <View className="flex-row justify-between items-center pb-3 border-b border-border">
              <Text className="text-sm text-muted">Average Book Length</Text>
              <Text className="text-sm font-semibold text-foreground">
                {stats.averagePagesDuration} pages
              </Text>
            </View>

            <View className="flex-row justify-between items-center pb-3 border-b border-border">
              <Text className="text-sm text-muted">Total Library</Text>
              <Text className="text-sm font-semibold text-foreground">
                {stats.totalBooksInLibrary} books
              </Text>
            </View>

            <View className="flex-row justify-between items-center">
              <Text className="text-sm text-muted">Completion Rate</Text>
              <Text className="text-sm font-semibold text-foreground">
                {stats.totalBooksInLibrary > 0
                  ? Math.round((stats.totalBooksRead / stats.totalBooksInLibrary) * 100)
                  : 0}
                %
              </Text>
            </View>
          </View>
        </View>

        {/* Recent Activity */}
        <View className="mb-6">
          <Text className="text-lg font-bold text-foreground mb-3">Last 7 Days</Text>

          <View className="bg-surface rounded-lg p-4 border border-border">
            {trends.slice(-7).map((trend, index) => {
              const date = new Date(trend.date);
              const dayName = date.toLocaleDateString('en-US', { weekday: 'short' });
              const hasActivity = trend.booksCompleted > 0 || trend.pagesRead > 0;

              return (
                <View
                  key={index}
                  className="flex-row justify-between items-center py-2"
                  style={{
                    borderBottomWidth: index < 6 ? 1 : 0,
                    borderBottomColor: colors.border,
                  }}
                >
                  <Text className="text-sm text-muted w-12">{dayName}</Text>
                  <View className="flex-1 flex-row items-center gap-2">
                    {hasActivity ? (
                      <>
                        {trend.booksCompleted > 0 && (
                          <View className="bg-success/20 px-2 py-1 rounded">
                            <Text className="text-xs font-medium text-success">
                              {trend.booksCompleted} book{trend.booksCompleted !== 1 ? 's' : ''}
                            </Text>
                          </View>
                        )}
                        {trend.pagesRead > 0 && (
                          <View className="bg-primary/20 px-2 py-1 rounded">
                            <Text className="text-xs font-medium text-primary">
                              {trend.pagesRead} pages
                            </Text>
                          </View>
                        )}
                      </>
                    ) : (
                      <Text className="text-xs text-muted italic">No activity</Text>
                    )}
                  </View>
                </View>
              );
            })}
          </View>
        </View>

        {/* Motivational Message */}
        <View className="bg-primary/10 rounded-lg p-4 border border-primary/20 mb-6">
          <Text className="text-sm font-semibold text-primary mb-1">Keep Reading! 📚</Text>
          <Text className="text-xs text-muted leading-relaxed">
            {stats.currentStreak > 0
              ? `You're on a ${stats.currentStreak}-day reading streak! Keep it up.`
              : stats.totalBooksRead > 0
                ? `You've read ${stats.totalBooksRead} books. Great progress!`
                : 'Start your reading journey by adding your first book.'}
          </Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
