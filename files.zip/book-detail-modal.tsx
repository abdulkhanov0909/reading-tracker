import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  Pressable,
  ScrollView,
  Modal,
  Alert,
  TextInput,
  FlatList,
} from 'react-native';
import { Book, Note } from '@/lib/storage';
import { useColors } from '@/hooks/use-colors';
import { EditBookModal } from '@/components/edit-book-modal';
import { EditNoteModal } from '@/components/edit-note-modal';

interface BookDetailModalProps {
  visible: boolean;
  book: Book | null;
  notes: Note[];
  onClose: () => void;
  onUpdateProgress: (currentPage: number) => Promise<void>;
  onMarkCompleted: () => Promise<void>;
  onDeleteBook: () => Promise<void>;
  onAddNote: (text: string) => Promise<void>;
  onDeleteNote: (noteId: string) => Promise<void>;
  onUpdateBook?: (bookId: string, updates: Partial<Book>) => Promise<void>;
  onUpdateNote?: (noteId: string, text: string) => Promise<void>;
}

export function BookDetailModal({
  visible,
  book,
  notes,
  onClose,
  onUpdateProgress,
  onMarkCompleted,
  onDeleteBook,
  onAddNote,
  onDeleteNote,
  onUpdateBook,
  onUpdateNote,
}: BookDetailModalProps) {
  const colors = useColors();
  const [progressInput, setProgressInput] = useState('');
  const [showProgressInput, setShowProgressInput] = useState(false);
  const [noteInput, setNoteInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [showEditBook, setShowEditBook] = useState(false);
  const [editingNote, setEditingNote] = useState<Note | null>(null);

  useEffect(() => {
    if (book) {
      setProgressInput(book.currentPage.toString());
    }
  }, [book]);

  if (!book) return null;

  const progressPercent = book.totalPages > 0 ? (book.currentPage / book.totalPages) * 100 : 0;

  const statusColor = {
    'want-to-read': colors.muted,
    'reading': colors.warning,
    'completed': colors.success,
  }[book.status];

  const statusLabel = {
    'want-to-read': 'Want to Read',
    'reading': 'Reading',
    'completed': 'Completed',
  }[book.status];

  const handleUpdateProgress = async () => {
    const newPage = parseInt(progressInput);
    if (isNaN(newPage) || newPage < 0 || newPage > book.totalPages) {
      Alert.alert('Invalid', `Please enter a number between 0 and ${book.totalPages}`);
      return;
    }
    setLoading(true);
    try {
      await onUpdateProgress(newPage);
      setShowProgressInput(false);
    } finally {
      setLoading(false);
    }
  };

  const handleAddNote = async () => {
    if (!noteInput.trim()) return;
    setLoading(true);
    try {
      await onAddNote(noteInput.trim());
      setNoteInput('');
    } finally {
      setLoading(false);
    }
  };

  const handleMarkCompleted = async () => {
    Alert.alert('Mark as Completed?', 'Are you sure you want to mark this book as completed?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Confirm',
        style: 'destructive',
        onPress: async () => {
          setLoading(true);
          try {
            await onMarkCompleted();
          } finally {
            setLoading(false);
          }
        },
      },
    ]);
  };

  const handleDeleteBook = async () => {
    Alert.alert('Delete Book?', 'This action cannot be undone.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          setLoading(true);
          try {
            await onDeleteBook();
            onClose();
          } finally {
            setLoading(false);
          }
        },
      },
    ]);
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent={false}
      onRequestClose={onClose}
    >
      <View className="flex-1 bg-background">
        {/* Header */}
        <View className="bg-surface border-b border-border px-4 py-3 pt-4">
          <View className="flex-row justify-between items-center">
            <Pressable
              onPress={() => onUpdateBook && setShowEditBook(true)}
              style={({ pressed }) => [{ opacity: pressed ? 0.6 : 1 }]}
            >
              <Text className="text-base font-medium text-primary">Edit</Text>
            </Pressable>
            <Text className="text-xl font-bold text-foreground flex-1 text-center" numberOfLines={1}>
              {book.title}
            </Text>
            <Pressable
              onPress={onClose}
              style={({ pressed }) => [{ opacity: pressed ? 0.6 : 1 }]}
            >
              <Text className="text-base font-medium text-primary">Done</Text>
            </Pressable>
          </View>
        </View>

        {/* Content */}
        <ScrollView className="flex-1 px-4 py-4">
          {/* Book Info */}
          <View className="bg-surface rounded-lg p-4 mb-4 border border-border">
            <Text className="text-sm text-muted mb-1">Author</Text>
            <Text className="text-base font-semibold text-foreground mb-4">{book.author}</Text>

            <View className="flex-row justify-between mb-4">
              <View>
                <Text className="text-sm text-muted mb-1">Total Pages</Text>
                <Text className="text-base font-semibold text-foreground">{book.totalPages}</Text>
              </View>
              <View>
                <Text className="text-sm text-muted mb-1">Status</Text>
                <View
                  className="px-2 py-1 rounded-full"
                  style={{ backgroundColor: `${statusColor}20` }}
                >
                  <Text className="text-sm font-medium" style={{ color: statusColor }}>
                    {statusLabel}
                  </Text>
                </View>
              </View>
            </View>

            {book.startDate && (
              <View className="mb-2">
                <Text className="text-sm text-muted mb-1">Started</Text>
                <Text className="text-sm text-foreground">
                  {new Date(book.startDate).toLocaleDateString()}
                </Text>
              </View>
            )}

            {book.completedDate && (
              <View>
                <Text className="text-sm text-muted mb-1">Completed</Text>
                <Text className="text-sm text-foreground">
                  {new Date(book.completedDate).toLocaleDateString()}
                </Text>
              </View>
            )}
          </View>

          {/* Progress Section */}
          {book.status === 'reading' && (
            <View className="bg-surface rounded-lg p-4 mb-4 border border-border">
              <View className="flex-row justify-between items-center mb-2">
                <Text className="text-base font-semibold text-foreground">Reading Progress</Text>
                <Text className="text-sm font-medium text-primary">{Math.round(progressPercent)}%</Text>
              </View>

              <View className="h-2 bg-border rounded-full overflow-hidden mb-3">
                <View
                  className="h-full bg-primary rounded-full"
                  style={{ width: `${progressPercent}%` }}
                />
              </View>

              <Text className="text-sm text-muted mb-3">
                {book.currentPage} of {book.totalPages} pages
              </Text>

              {!showProgressInput ? (
                <Pressable
                  onPress={() => setShowProgressInput(true)}
                  style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
                >
                  <View className="bg-primary/10 py-2 rounded px-3 items-center">
                    <Text className="text-sm font-medium text-primary">Update Progress</Text>
                  </View>
                </Pressable>
              ) : (
                <View className="gap-2">
                  <TextInput
                    placeholder="Enter current page"
                    placeholderTextColor={colors.muted}
                    value={progressInput}
                    onChangeText={setProgressInput}
                    keyboardType="number-pad"
                    className="bg-background border border-border rounded-lg px-3 py-2 text-foreground"
                  />
                  <View className="flex-row gap-2">
                    <Pressable
                      onPress={() => setShowProgressInput(false)}
                      className="flex-1"
                      style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
                    >
                      <View className="bg-border py-2 rounded items-center">
                        <Text className="text-sm font-medium text-foreground">Cancel</Text>
                      </View>
                    </Pressable>
                    <Pressable
                      onPress={handleUpdateProgress}
                      disabled={loading}
                      className="flex-1"
                      style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
                    >
                      <View className="bg-primary py-2 rounded items-center">
                        <Text className="text-sm font-medium text-background">Save</Text>
                      </View>
                    </Pressable>
                  </View>
                </View>
              )}
            </View>
          )}

          {/* Notes Section */}
          <View className="mb-4">
            <Text className="text-base font-semibold text-foreground mb-3">Personal Notes</Text>

            {/* Add Note Input */}
            <View className="bg-surface rounded-lg p-3 mb-3 border border-border">
              <TextInput
                placeholder="Add a note..."
                placeholderTextColor={colors.muted}
                value={noteInput}
                onChangeText={setNoteInput}
                multiline
                editable={!loading}
                className="text-foreground mb-2"
                style={{ minHeight: 60 }}
              />
              <Pressable
                onPress={handleAddNote}
                disabled={loading || !noteInput.trim()}
                style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
              >
                <View
                  className="py-2 rounded items-center"
                  style={{
                    backgroundColor:
                      loading || !noteInput.trim() ? `${colors.primary}50` : colors.primary,
                  }}
                >
                  <Text className="text-sm font-medium text-background">Add Note</Text>
                </View>
              </Pressable>
            </View>

            {/* Notes List */}
            {notes.length > 0 ? (
              <FlatList
                data={notes}
                keyExtractor={(item) => item.id}
                scrollEnabled={false}
                renderItem={({ item }) => (
                  <View className="bg-surface rounded-lg p-3 mb-2 border border-border">
                    <View className="flex-row justify-between items-start mb-2">
                      <Text className="text-xs text-muted flex-1">
                        {new Date(item.createdAt).toLocaleDateString()} at{' '}
                        {new Date(item.createdAt).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </Text>
                      <View className="flex-row gap-3">
                        <Pressable
                          onPress={() => setEditingNote(item)}
                          style={({ pressed }) => [{ opacity: pressed ? 0.6 : 1 }]}
                        >
                          <Text className="text-xs text-primary font-medium">Edit</Text>
                        </Pressable>
                        <Pressable
                          onPress={() => {
                            Alert.alert('Delete Note?', 'This action cannot be undone.', [
                              { text: 'Cancel', style: 'cancel' },
                              {
                                text: 'Delete',
                                style: 'destructive',
                                onPress: () => onDeleteNote(item.id),
                              },
                            ]);
                          }}
                          style={({ pressed }) => [{ opacity: pressed ? 0.6 : 1 }]}
                        >
                          <Text className="text-xs text-error font-medium">Delete</Text>
                        </Pressable>
                      </View>
                    </View>
                    <Text className="text-sm text-foreground leading-relaxed">{item.text}</Text>
                  </View>
                )}
              />
            ) : (
              <Text className="text-sm text-muted text-center py-4">No notes yet</Text>
            )}
          </View>

          {/* Action Buttons */}
          <View className="gap-2 mb-4">
            {book.status === 'reading' && (
              <Pressable
                onPress={handleMarkCompleted}
                disabled={loading}
                style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
              >
                <View className="bg-success/10 py-3 rounded-lg items-center">
                  <Text className="text-sm font-medium text-success">Mark as Completed</Text>
                </View>
              </Pressable>
            )}

            <Pressable
              onPress={handleDeleteBook}
              disabled={loading}
              style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
            >
              <View className="bg-error/10 py-3 rounded-lg items-center">
                <Text className="text-sm font-medium text-error">Delete Book</Text>
              </View>
            </Pressable>
          </View>
        </ScrollView>
      </View>

      {/* Edit Book Modal */}
      {onUpdateBook && (
        <EditBookModal
          visible={showEditBook}
          book={book}
          onClose={() => setShowEditBook(false)}
          onSave={async (bookId, updates) => {
            await onUpdateBook(bookId, updates);
            setShowEditBook(false);
          }}
        />
      )}

      {/* Edit Note Modal */}
      {onUpdateNote && (
        <EditNoteModal
          visible={!!editingNote}
          note={editingNote}
          onClose={() => setEditingNote(null)}
          onSave={async (noteId, text) => {
            await onUpdateNote(noteId, text);
            setEditingNote(null);
          }}
        />
      )}
    </Modal>
  );
}
