# Reading Tracker — Mobile App Design

## Screen List

The Reading Tracker app consists of the following screens organized in a tab-based navigation structure:

1. **Library Screen** — Main screen showing all books in the user's collection
2. **Add Book Screen** — Form to add a new book with details
3. **Book Detail Screen** — Full book information, progress tracking, and notes
4. **Search Screen** — Search and filter books by title, author, or status
5. **Settings Screen** — App preferences and data management

## Primary Content and Functionality

### Library Screen (Home Tab)
- **Content**: Grid or list view of all books with cover images, titles, and reading status badges
- **Functionality**:
  - Display books grouped by reading status (Reading, Completed, Want to Read)
  - Tap book to open Detail screen
  - Pull-to-refresh to reload data
  - Quick actions: mark as completed, add to favorites
  - Empty state when no books exist with CTA to add first book

### Add Book Screen
- **Content**: Form fields for book information
- **Fields**:
  - Book title (required)
  - Author name (required)
  - ISBN (optional, for lookup)
  - Cover image (optional, with camera/gallery picker)
  - Total pages (required, for progress tracking)
  - Reading status (dropdown: Want to Read, Reading, Completed)
  - Start date (optional, auto-populated with today)
  - Target completion date (optional)
- **Functionality**:
  - Save button to add book to library
  - Cancel to return to Library screen
  - Input validation with error messages
  - Auto-focus first field on open

### Book Detail Screen
- **Content**: Complete book information with progress and notes
- **Sections**:
  - Header: Cover image, title, author, status badge
  - Progress section: Current page / Total pages with progress bar
  - Reading stats: Start date, target date, pages read today
  - Notes section: List of personal notes with timestamps
  - Actions: Edit book, update progress, add note, delete book
- **Functionality**:
  - Swipe up progress bar to quickly update current page
  - Add/edit/delete notes with timestamps
  - Mark book as completed
  - Share book details (iOS Share sheet)
  - Edit book information

### Search Screen
- **Content**: Search bar with filters and results list
- **Filters**:
  - Reading status (All, Want to Read, Reading, Completed)
  - Sort by (Title, Author, Date Added, Progress)
  - Search by title or author name
- **Functionality**:
  - Real-time search results
  - Tap result to open Detail screen
  - Filter persistence during session

### Settings Screen
- **Content**: App preferences and data management
- **Options**:
  - Theme (Light/Dark/System)
  - Display preferences (List/Grid view)
  - Data export (JSON backup)
  - Data import (restore from backup)
  - About app

## Key User Flows

### Flow 1: Add a New Book
1. User taps "+" button or "Add Book" CTA on empty Library
2. Add Book screen opens with form fields
3. User fills in book details (title, author, pages, etc.)
4. User taps "Save"
5. Book is added to library and Library screen refreshes
6. User sees new book in the list

### Flow 2: Track Reading Progress
1. User opens Library screen
2. User taps on a book in "Reading" status
3. Book Detail screen opens showing current page and progress bar
4. User taps progress bar or "Update Progress" button
5. Progress input sheet appears
6. User enters current page number
7. Sheet closes and Detail screen updates with new progress
8. User can add a note about reading session (optional)

### Flow 3: Add Personal Notes
1. User opens Book Detail screen
2. User scrolls to Notes section
3. User taps "Add Note" button
4. Note input sheet appears with text field
5. User types note and taps "Save"
6. Note appears in list with timestamp
7. User can edit or delete notes by swiping or tapping options

### Flow 4: Mark Book as Completed
1. User opens Book Detail screen for a book in "Reading" status
2. User taps "Mark as Completed" button
3. Confirmation dialog appears
4. User confirms action
5. Book status changes to "Completed" with completion date
6. Book moves to "Completed" section in Library

### Flow 5: Search and Filter Books
1. User taps Search tab
2. Search screen opens with search bar and filters
3. User types book title or author name
4. Results update in real-time
5. User can apply status filter or sort preference
6. User taps result to view Book Detail screen

## Color Choices

The Reading Tracker uses a warm, literary-inspired color palette:

| Element | Light Mode | Dark Mode | Purpose |
|---------|-----------|----------|---------|
| **Primary** | `#8B4513` (Saddle Brown) | `#D2691E` (Chocolate) | Buttons, highlights, key actions |
| **Background** | `#FAFAF8` (Off-white) | `#1A1A18` (Near-black) | Screen backgrounds |
| **Surface** | `#FFFFFF` (White) | `#2A2A28` (Dark gray) | Cards, input fields |
| **Foreground** | `#2C2C2C` (Dark gray) | `#F5F5F3` (Off-white) | Primary text |
| **Muted** | `#8A8A86` (Medium gray) | `#A0A09C` (Light gray) | Secondary text, hints |
| **Border** | `#E8E8E4` (Light gray) | `#3A3A38` (Dark gray) | Dividers, borders |
| **Success** | `#4CAF50` (Green) | `#66BB6A` (Light green) | Completed status, confirmations |
| **Warning** | `#FF9800` (Orange) | `#FFB74D` (Light orange) | In-progress status, cautions |
| **Error** | `#F44336` (Red) | `#EF5350` (Light red) | Delete actions, errors |

## Design Principles

- **One-handed usage**: All interactive elements positioned within thumb reach (bottom half of screen)
- **iOS-first**: Follows Apple Human Interface Guidelines with native iOS patterns
- **Minimal visual hierarchy**: Clear distinction between primary actions and secondary options
- **Reading-focused**: Typography emphasizes readability with generous line heights and spacing
- **Subtle feedback**: Haptic feedback on key interactions, smooth transitions between screens
