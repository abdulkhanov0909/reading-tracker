import * as ImagePickerLib from 'expo-image-picker';
import * as FileSystem from 'expo-file-system/legacy';
import { Platform } from 'react-native';

export interface PickedImage {
  uri: string;
  width: number;
  height: number;
  size: number;
  mimeType: string;
}

/**
 * Request camera permissions
 */
export async function requestCameraPermissions(): Promise<boolean> {
  if (Platform.OS === 'web') return true;

  const { status } = await ImagePickerLib.requestCameraPermissionsAsync();
  return status === 'granted';
}

/**
 * Request media library permissions
 */
export async function requestMediaLibraryPermissions(): Promise<boolean> {
  if (Platform.OS === 'web') return true;

  const { status } = await ImagePickerLib.requestMediaLibraryPermissionsAsync();
  return status === 'granted';
}

/**
 * Pick image from camera
 */
export async function pickImageFromCamera(): Promise<PickedImage | null> {
  try {
    const hasPermission = await requestCameraPermissions();
    if (!hasPermission) {
      console.warn('Camera permission denied');
      return null;
    }

    const result = await ImagePickerLib.launchCameraAsync({
      allowsEditing: true,
      aspect: [2, 3], // Book cover aspect ratio
      quality: 0.8,
    });

    if (result.canceled) {
      return null;
    }

    const asset = result.assets[0];

    return {
      uri: asset.uri,
      width: asset.width,
      height: asset.height,
      size: 0,
      mimeType: 'image/jpeg',
    };
  } catch (error) {
    console.error('Error picking image from camera:', error);
    return null;
  }
}

/**
 * Pick image from media library
 */
export async function pickImageFromLibrary(): Promise<PickedImage | null> {
  try {
    const hasPermission = await requestMediaLibraryPermissions();
    if (!hasPermission) {
      console.warn('Media library permission denied');
      return null;
    }

    const result = await ImagePickerLib.launchImageLibraryAsync({
      allowsEditing: true,
      aspect: [2, 3], // Book cover aspect ratio
      quality: 0.8,
      mediaTypes: ImagePickerLib.MediaTypeOptions.Images,
    });

    if (result.canceled) {
      return null;
    }

    const asset = result.assets[0];

    return {
      uri: asset.uri,
      width: asset.width,
      height: asset.height,
      size: 0,
      mimeType: 'image/jpeg',
    };
  } catch (error) {
    console.error('Error picking image from library:', error);
    return null;
  }
}

/**
 * Save image to app documents directory
 */
export async function saveImageToAppDirectory(
  imageUri: string,
  bookId: string
): Promise<string | null> {
  try {
    const filename = `book_cover_${bookId}.jpg`;
    const destPath = `${FileSystem.documentDirectory}book_covers/${filename}`;

    // Create directory if it doesn't exist
    const dirPath = `${FileSystem.documentDirectory}book_covers`;
    const dirInfo = await FileSystem.getInfoAsync(dirPath);
    if (!dirInfo.exists) {
      await FileSystem.makeDirectoryAsync(dirPath, { intermediates: true });
    }

    // Copy file to app directory
    await FileSystem.copyAsync({
      from: imageUri,
      to: destPath,
    });

    return destPath;
  } catch (error) {
    console.error('Error saving image:', error);
    return null;
  }
}

/**
 * Delete image from app directory
 */
export async function deleteImageFromAppDirectory(imageUri: string): Promise<boolean> {
  try {
    const fileInfo = await FileSystem.getInfoAsync(imageUri);
    if (fileInfo.exists) {
      await FileSystem.deleteAsync(imageUri);
      return true;
    }
    return false;
  } catch (error) {
    console.error('Error deleting image:', error);
    return false;
  }
}

/**
 * Compress image
 */
export async function compressImage(
  imageUri: string,
  quality: number = 0.8
): Promise<PickedImage | null> {
  try {
    const fileInfo = await FileSystem.getInfoAsync(imageUri);
    if (!fileInfo.exists) {
      return null;
    }

    // For web and already optimized images, return as is
    const result = await ImagePickerLib.launchImageLibraryAsync({
      allowsEditing: false,
      quality,
      mediaTypes: ImagePickerLib.MediaTypeOptions.Images,
    });

    if (result.canceled) {
      return null;
    }

    const asset = result.assets[0];

    return {
      uri: asset.uri,
      width: asset.width,
      height: asset.height,
      size: 0,
      mimeType: 'image/jpeg',
    };
  } catch (error) {
    console.error('Error compressing image:', error);
    return null;
  }
}
