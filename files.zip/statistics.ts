import { Book } from './storage';

export interface ReadingStats {
  totalBooksRead: number;
  totalPagesRead: number;
  averagePagesPerDay: number;
  currentStreak: number;
  longestStreak: number;
  booksInProgress: number;
  totalBooksInLibrary: number;
  averagePagesDuration: number;
}

export interface ReadingTrend {
  date: string;
  pagesRead: number;
  booksCompleted: number;
}

/**
 * Calculate reading statistics from books array
 */
export function calculateReadingStats(books: Book[]): ReadingStats {
  const completedBooks = books.filter((b) => b.status === 'completed');
  const booksInProgress = books.filter((b) => b.status === 'reading');

  const totalBooksRead = completedBooks.length;
  const totalPagesRead = completedBooks.reduce((sum, b) => sum + b.totalPages, 0);
  const totalBooksInLibrary = books.length;

  // Calculate average pages per day
  const daysSinceFirstBook = calculateDaysSinceFirstBook(books);
  const averagePagesPerDay = daysSinceFirstBook > 0 ? totalPagesRead / daysSinceFirstBook : 0;

  // Calculate reading streaks
  const { currentStreak, longestStreak } = calculateReadingStreaks(completedBooks);

  // Calculate average pages per book
  const averagePagesDuration = totalBooksRead > 0 ? totalPagesRead / totalBooksRead : 0;

  return {
    totalBooksRead,
    totalPagesRead,
    averagePagesPerDay: Math.round(averagePagesPerDay * 10) / 10,
    currentStreak,
    longestStreak,
    booksInProgress: booksInProgress.length,
    totalBooksInLibrary,
    averagePagesDuration: Math.round(averagePagesDuration),
  };
}

/**
 * Calculate days since the first book was added
 */
function calculateDaysSinceFirstBook(books: Book[]): number {
  if (books.length === 0) return 0;

  const oldestBook = books.reduce((oldest, current) =>
    current.createdAt < oldest.createdAt ? current : oldest
  );

  const daysDiff = Math.floor((Date.now() - oldestBook.createdAt) / (1000 * 60 * 60 * 24));
  return Math.max(daysDiff, 1); // At least 1 day
}

/**
 * Calculate current and longest reading streaks
 * A streak is consecutive days with at least one book completed
 */
function calculateReadingStreaks(
  completedBooks: Book[]
): { currentStreak: number; longestStreak: number } {
  if (completedBooks.length === 0) {
    return { currentStreak: 0, longestStreak: 0 };
  }

  // Group books by completion date
  const completionsByDate = new Map<string, number>();

  completedBooks.forEach((book) => {
    if (book.completedDate) {
      const date = new Date(book.completedDate).toISOString().split('T')[0];
      completionsByDate.set(date, (completionsByDate.get(date) || 0) + 1);
    }
  });

  if (completionsByDate.size === 0) {
    return { currentStreak: 0, longestStreak: 0 };
  }

  const sortedDates = Array.from(completionsByDate.keys()).sort();
  let currentStreak = 0;
  let longestStreak = 0;
  let tempStreak = 1;

  for (let i = 1; i < sortedDates.length; i++) {
    const prevDate = new Date(sortedDates[i - 1]);
    const currentDate = new Date(sortedDates[i]);
    const dayDiff = Math.floor(
      (currentDate.getTime() - prevDate.getTime()) / (1000 * 60 * 60 * 24)
    );

    if (dayDiff === 1) {
      tempStreak++;
    } else {
      longestStreak = Math.max(longestStreak, tempStreak);
      tempStreak = 1;
    }
  }

  longestStreak = Math.max(longestStreak, tempStreak);

  // Check if today or yesterday has a completion for current streak
  const today = new Date().toISOString().split('T')[0];
  const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];

  if (completionsByDate.has(today)) {
    currentStreak = tempStreak;
  } else if (completionsByDate.has(yesterday)) {
    currentStreak = tempStreak;
  } else {
    currentStreak = 0;
  }

  return { currentStreak, longestStreak };
}

/**
 * Get reading trends for the last N days
 */
export function getReadingTrends(books: Book[], days: number = 30): ReadingTrend[] {
  const trends = new Map<string, ReadingTrend>();

  // Initialize all days with 0
  for (let i = days - 1; i >= 0; i--) {
    const date = new Date(Date.now() - i * 86400000).toISOString().split('T')[0];
    trends.set(date, { date, pagesRead: 0, booksCompleted: 0 });
  }

  // Add book completions
  books
    .filter((b) => b.status === 'completed' && b.completedDate)
    .forEach((book) => {
      const date = new Date(book.completedDate!).toISOString().split('T')[0];
      const trend = trends.get(date);
      if (trend) {
        trend.pagesRead += book.totalPages;
        trend.booksCompleted += 1;
      }
    });

  return Array.from(trends.values());
}

/**
 * Calculate reading goals and progress
 */
export function calculateReadingGoals(books: Book[]): {
  weeklyGoal: number;
  weeklyProgress: number;
  monthlyGoal: number;
  monthlyProgress: number;
} {
  const completedBooks = books.filter((b) => b.status === 'completed');
  const now = Date.now();
  const weekAgo = now - 7 * 86400000;
  const monthAgo = now - 30 * 86400000;

  const weeklyCompleted = completedBooks.filter((b) => b.completedDate && b.completedDate > weekAgo)
    .length;
  const monthlyCompleted = completedBooks.filter((b) => b.completedDate && b.completedDate > monthAgo)
    .length;

  return {
    weeklyGoal: 2,
    weeklyProgress: weeklyCompleted,
    monthlyGoal: 8,
    monthlyProgress: monthlyCompleted,
  };
}
