                  </View>
                </Pressable>
              ))}
            </View>
          </View>
        </ScrollView>

        {/* Footer */}
        <View className="bg-surface border-t border-border px-4 py-4">
          <Pressable
            onPress={handleAdd}
            disabled={loading}
            style={({ pressed }) => [
              {
                opacity: pressed && !loading ? 0.9 : 1,
              },
            ]}
          >
            <View
              className="py-3 rounded-lg items-center justify-center"
              style={{
                backgroundColor: loading ? `${colors.primary}50` : colors.primary,
              }}
            >
              <Text className="text-base font-semibold text-background">
                {loading ? 'Adding...' : 'Add Book'}
              </Text>
            </View>
          </Pressable>
        </View>
      </View>
    </Modal>

    {/* Image Picker Modal */}
    <ImagePickerModal
      visible={showImagePicker}
      onClose={() => setShowImagePicker(false)}
      onImageSelected={setSelectedImage}
      currentImageUri={selectedImage?.uri}
    />
  );
}
