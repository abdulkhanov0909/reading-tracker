import React from 'react';
import { View, ViewProps } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

interface ScreenContainerProps extends ViewProps {
  children: React.ReactNode;
  className?: string;
}

export function ScreenContainer({ children, className = '', ...props }: ScreenContainerProps) {
  return (
    <SafeAreaView className={`flex-1 bg-background ${className}`} {...props}>
      {children}
    </SafeAreaView>
  );
}
