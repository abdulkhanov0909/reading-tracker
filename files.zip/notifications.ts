import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface NotificationSettings {
  dailyRemindersEnabled: boolean;
  reminderTime: string; // HH:mm format
  completionAlertsEnabled: boolean;
  completionAlertThreshold: number; // percentage
}

const NOTIFICATION_SETTINGS_KEY = '@reading_tracker_notification_settings';

/**
 * Initialize notifications
 */
export async function initializeNotifications(): Promise<void> {
  if (Platform.OS === 'web') return;

  // Set notification handler
  Notifications.setNotificationHandler({
    handleNotification: async () => ({
      shouldShowAlert: true,
      shouldPlaySound: true,
      shouldSetBadge: true,
      shouldShowBanner: true,
      shouldShowList: true,
    }),
  });

  // Request permissions
  const { status } = await Notifications.requestPermissionsAsync();
  if (status !== 'granted') {
    console.warn('Notification permissions not granted');
  }
}

/**
 * Get notification settings
 */
export async function getNotificationSettings(): Promise<NotificationSettings> {
  try {
    const data = await AsyncStorage.getItem(NOTIFICATION_SETTINGS_KEY);
    if (data) {
      return JSON.parse(data);
    }
  } catch (error) {
    console.error('Error reading notification settings:', error);
  }

  // Return default settings
  return {
    dailyRemindersEnabled: true,
    reminderTime: '19:00',
    completionAlertsEnabled: true,
    completionAlertThreshold: 80,
  };
}

/**
 * Save notification settings
 */
export async function saveNotificationSettings(
  settings: NotificationSettings
): Promise<void> {
  try {
    await AsyncStorage.setItem(NOTIFICATION_SETTINGS_KEY, JSON.stringify(settings));
  } catch (error) {
    console.error('Error saving notification settings:', error);
  }
}

/**
 * Schedule daily reading reminder
 */
export async function scheduleDailyReminder(time: string): Promise<void> {
  if (Platform.OS === 'web') return;

  try {
    // Cancel existing reminders
    await Notifications.cancelAllScheduledNotificationsAsync();

    const [hours, minutes] = time.split(':').map(Number);
    const now = new Date();
    const scheduledTime = new Date();
    scheduledTime.setHours(hours, minutes, 0, 0);

    // If time has passed today, schedule for tomorrow
    if (scheduledTime <= now) {
      scheduledTime.setDate(scheduledTime.getDate() + 1);
    }

    // Schedule for every day
    const trigger = {
      type: 'calendar' as const,
      hour: hours,
      minute: minutes,
      repeats: true,
    };

    await Notifications.scheduleNotificationAsync({
      content: {
        title: '📚 Time to Read!',
        body: 'Pick up your book and continue your reading journey.',
        sound: 'default',
        badge: 1,
      },
      trigger: trigger as any,
    });

    console.log(`Daily reminder scheduled for ${time}`);
  } catch (error) {
    console.error('Error scheduling daily reminder:', error);
  }
}

/**
 * Send completion alert for a book
 */
export async function sendCompletionAlert(bookTitle: string, pagesRemaining: number): Promise<void> {
  if (Platform.OS === 'web') return;

  try {
    await Notifications.scheduleNotificationAsync({
      content: {
        title: '🎉 Almost Done!',
        body: `You're close to finishing "${bookTitle}"! Only ${pagesRemaining} pages left.`,
        sound: 'default',
        badge: 1,
      },
      trigger: null, // Send immediately
    });
  } catch (error) {
    console.error('Error sending completion alert:', error);
  }
}

/**
 * Send book completed notification
 */
export async function sendBookCompletedNotification(bookTitle: string): Promise<void> {
  if (Platform.OS === 'web') return;

  try {
    await Notifications.scheduleNotificationAsync({
      content: {
        title: '✨ Book Completed!',
        body: `Congratulations! You finished "${bookTitle}". Great job!`,
        sound: 'default',
        badge: 1,
      },
      trigger: null, // Send immediately
    });
  } catch (error) {
    console.error('Error sending book completed notification:', error);
  }
}

/**
 * Send reading streak notification
 */
export async function sendReadingStreakNotification(streak: number): Promise<void> {
  if (Platform.OS === 'web') return;

  try {
    const messages = [
      'You are on fire! 🔥',
      'Amazing consistency! 💪',
      'Keep the momentum going! 🚀',
      'You are a reading champion! 🏆',
    ];

    const message = messages[Math.floor(Math.random() * messages.length)];

    await Notifications.scheduleNotificationAsync({
      content: {
        title: `${streak}-Day Reading Streak!`,
        body: message,
        sound: 'default',
        badge: 1,
      },
      trigger: null, // Send immediately
    });
  } catch (error) {
    console.error('Error sending streak notification:', error);
  }
}

/**
 * Cancel all scheduled notifications
 */
export async function cancelAllNotifications(): Promise<void> {
  if (Platform.OS === 'web') return;

  try {
    await Notifications.cancelAllScheduledNotificationsAsync();
  } catch (error) {
    console.error('Error canceling notifications:', error);
  }
}
