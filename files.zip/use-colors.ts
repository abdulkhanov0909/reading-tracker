import { useColorScheme } from 'react-native';

export function useColors() {
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';

  return {
    primary: isDark ? '#D2691E' : '#8B4513',
    background: isDark ? '#1A1A18' : '#FAFAF8',
    surface: isDark ? '#2A2A28' : '#FFFFFF',
    foreground: isDark ? '#F5F5F3' : '#2C2C2C',
    muted: isDark ? '#A0A09C' : '#8A8A86',
    border: isDark ? '#3A3A38' : '#E8E8E4',
    success: isDark ? '#66BB6A' : '#4CAF50',
    warning: isDark ? '#FFB74D' : '#FF9800',
    error: isDark ? '#EF5350' : '#F44336',
  };
}
