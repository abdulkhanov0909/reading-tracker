import React, { useState, useEffect } from 'react';
import { ScrollView, Text, View, Pressable, Alert, Share, Switch, TextInput } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { useBooks } from '@/lib/book-context';
import { useColorScheme } from '@/hooks/use-color-scheme';
import { useColors } from '@/hooks/use-colors';
import { storage } from '@/lib/storage';
import { getNotificationSettings, saveNotificationSettings, scheduleDailyReminder, cancelAllNotifications } from '@/lib/notifications';
import * as FileSystem from 'expo-file-system/legacy';

export default function SettingsScreen() {
  const colors = useColors();
  const colorScheme = useColorScheme();
  const { books, notes, refreshBooks } = useBooks();
  const [exporting, setExporting] = useState(false);
  const [notificationSettings, setNotificationSettings] = useState<any>(null);

  useEffect(() => {
    loadNotificationSettings();
  }, []);

  const loadNotificationSettings = async () => {
    const settings = await getNotificationSettings();
    setNotificationSettings(settings);
  };

  const handleNotificationToggle = async (enabled: boolean) => {
    if (notificationSettings) {
      const updated = { ...notificationSettings, dailyRemindersEnabled: enabled };
      setNotificationSettings(updated);
      await saveNotificationSettings(updated);
      if (enabled) {
        await scheduleDailyReminder(updated.reminderTime);
      } else {
        await cancelAllNotifications();
      }
    }
  };

  const handleReminderTimeChange = async (time: string) => {
    if (notificationSettings) {
      const updated = { ...notificationSettings, reminderTime: time };
      setNotificationSettings(updated);
      await saveNotificationSettings(updated);
      if (updated.dailyRemindersEnabled) {
        await scheduleDailyReminder(time);
      }
    }
  };

  const handleExportData = async () => {
    setExporting(true);
    try {
      const data = await storage.exportData();
      const jsonString = JSON.stringify(data, null, 2);
      const filename = `reading-tracker-backup-${new Date().toISOString().split('T')[0]}.json`;
      const filepath = `${FileSystem.documentDirectory}${filename}`;

      await FileSystem.writeAsStringAsync(filepath, jsonString);

      // Share the file
      await Share.share({
        url: filepath,
        title: 'Reading Tracker Backup',
        message: 'Here is your reading tracker backup',
      });
    } catch (error) {
      Alert.alert('Error', 'Failed to export data');
      console.error('Export error:', error);
    } finally {
      setExporting(false);
    }
  };

  const handleImportData = async () => {
    Alert.alert(
      'Import Data?',
      'This will replace all your current data. Make sure you have a backup first.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Import',
          style: 'default',
          onPress: async () => {
            try {
              // In a real app, you'd use DocumentPicker here
              // For now, we'll show instructions
              Alert.alert(
                'Import Instructions',
                'To import data:\n\n1. Place your backup JSON file in the app\'s documents directory\n2. The file should contain "books" and "notes" arrays\n3. Use the format from Export Data',
                [{ text: 'OK' }]
              );
              // Example implementation:
              // const result = await DocumentPicker.getDocumentAsync({type: 'application/json'});
              // const content = await FileSystem.readAsStringAsync(result.uri);
              // const data = JSON.parse(content);
              // await storage.importData(data);
              // await refreshBooks();
            } catch (error) {
              Alert.alert('Error', 'Failed to import data');
            }
          },
        },
      ]
    );
  };

  const handleClearData = () => {
    Alert.alert(
      'Clear All Data?',
      'This will delete all books and notes. This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Clear',
          style: 'destructive',
          onPress: async () => {
            try {
              await storage.clearAllData();
              await refreshBooks();
              Alert.alert('Success', 'All data has been cleared');
            } catch (error) {
              Alert.alert('Error', 'Failed to clear data');
            }
          },
        },
      ]
    );
  };

  const totalBooks = books.length;
  const totalNotes = Array.from(notes.values()).reduce((sum, arr) => sum + arr.length, 0);
  const readingBooks = books.filter((b) => b.status === 'reading').length;
  const completedBooks = books.filter((b) => b.status === 'completed').length;

  return (
    <ScreenContainer className="p-0">
      {/* Header */}
      <View className="bg-surface border-b border-border px-4 py-3">
        <Text className="text-2xl font-bold text-foreground">Settings</Text>
      </View>

      {/* Content */}
      <ScrollView className="flex-1 px-4 py-4">
        {/* Statistics Section */}
        <View className="mb-6">
          <Text className="text-lg font-bold text-foreground mb-3">Your Library</Text>
          <View className="bg-surface rounded-lg p-4 border border-border">
            <View className="flex-row justify-between mb-3">
              <View>
                <Text className="text-sm text-muted mb-1">Total Books</Text>
                <Text className="text-2xl font-bold text-foreground">{totalBooks}</Text>
              </View>
              <View>
                <Text className="text-sm text-muted mb-1">Reading</Text>
                <Text className="text-2xl font-bold text-warning">{readingBooks}</Text>
              </View>
              <View>
                <Text className="text-sm text-muted mb-1">Completed</Text>
                <Text className="text-2xl font-bold text-success">{completedBooks}</Text>
              </View>
            </View>
            <View className="border-t border-border pt-3">
              <Text className="text-sm text-muted">Personal Notes</Text>
              <Text className="text-lg font-semibold text-foreground">{totalNotes}</Text>
            </View>
          </View>
        </View>

        {/* Theme Section */}
        <View className="mb-6">
          <Text className="text-lg font-bold text-foreground mb-3">Appearance</Text>
          <View className="bg-surface rounded-lg p-4 border border-border">
            <Text className="text-sm text-muted mb-2">Current Theme</Text>
            <Text className="text-base font-semibold text-foreground capitalize">
              {colorScheme === 'dark' ? 'Dark' : 'Light'} Mode
            </Text>
            <Text className="text-xs text-muted mt-2">
              Theme is set to follow your system settings
            </Text>
          </View>
        </View>

        {/* Notifications Section */}
        {notificationSettings && (
          <View className="mb-6">
            <Text className="text-lg font-bold text-foreground mb-3">Notifications</Text>
            <View className="bg-surface rounded-lg p-4 border border-border gap-4">
              <View className="flex-row justify-between items-center">
                <View className="flex-1">
                  <Text className="text-sm font-semibold text-foreground">Daily Reminders</Text>
                  <Text className="text-xs text-muted mt-1">Get reminded to read every day</Text>
                </View>
                <Switch
                  value={notificationSettings.dailyRemindersEnabled}
                  onValueChange={handleNotificationToggle}
                  trackColor={{ false: colors.border, true: colors.primary }}
                />
              </View>

              {notificationSettings.dailyRemindersEnabled && (
                <View>
                  <Text className="text-sm font-semibold text-foreground mb-2">Reminder Time</Text>
                  <TextInput
                    placeholder="HH:mm"
                    value={notificationSettings.reminderTime}
                    onChangeText={handleReminderTimeChange}
                    maxLength={5}
                    className="bg-background border border-border rounded-lg px-3 py-2 text-foreground text-center"
                  />
                  <Text className="text-xs text-muted mt-1">Format: HH:mm (24-hour)</Text>
                </View>
              )}
            </View>
          </View>
        )}

        {/* Data Management Section */}
        <View className="mb-6">
          <Text className="text-lg font-bold text-foreground mb-3">Data Management</Text>

          {/* Export Button */}
          <Pressable
            onPress={handleExportData}
            disabled={exporting}
            style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
          >
            <View className="bg-surface rounded-lg p-4 border border-border mb-2">
              <Text className="text-base font-semibold text-primary">
                {exporting ? 'Exporting...' : 'Export Data'}
              </Text>
              <Text className="text-xs text-muted mt-1">
                Download a backup of all your books and notes
              </Text>
            </View>
          </Pressable>

          {/* Import Button */}
          <Pressable
            onPress={handleImportData}
            style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
          >
            <View className="bg-surface rounded-lg p-4 border border-border mb-2">
              <Text className="text-base font-semibold text-primary">Import Data</Text>
              <Text className="text-xs text-muted mt-1">
                Restore your books and notes from a backup file
              </Text>
            </View>
          </Pressable>

          {/* Clear Data Button */}
          <Pressable
            onPress={handleClearData}
            style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
          >
            <View className="bg-surface rounded-lg p-4 border border-error/30">
              <Text className="text-base font-semibold text-error">Clear All Data</Text>
              <Text className="text-xs text-muted mt-1">
                Permanently delete all books and notes
              </Text>
            </View>
          </Pressable>
        </View>

        {/* About Section */}
        <View className="mb-6">
          <Text className="text-lg font-bold text-foreground mb-3">About</Text>
          <View className="bg-surface rounded-lg p-4 border border-border">
            <View className="mb-3">
              <Text className="text-sm text-muted mb-1">App Name</Text>
              <Text className="text-base font-semibold text-foreground">Reading Tracker</Text>
            </View>
            <View className="mb-3">
              <Text className="text-sm text-muted mb-1">Version</Text>
              <Text className="text-base font-semibold text-foreground">1.0.0</Text>
            </View>
            <View>
              <Text className="text-sm text-muted mb-1">Description</Text>
              <Text className="text-sm text-foreground leading-relaxed">
                Track your reading progress, manage your book collection, and keep personal notes on every book you read.
              </Text>
            </View>
          </View>
        </View>

        {/* Tips Section */}
        <View className="mb-6">
          <Text className="text-lg font-bold text-foreground mb-3">Tips</Text>
          <View className="bg-surface rounded-lg p-4 border border-border gap-3">
            <View>
              <Text className="text-sm font-semibold text-foreground mb-1">📚 Organize Your Library</Text>
              <Text className="text-xs text-muted">
                Use the search screen to filter books by status and sort by your preferred criteria.
              </Text>
            </View>
            <View>
              <Text className="text-sm font-semibold text-foreground mb-1">📝 Take Notes</Text>
              <Text className="text-xs text-muted">
                Add personal notes to each book to capture your thoughts and favorite quotes.
              </Text>
            </View>
            <View>
              <Text className="text-sm font-semibold text-foreground mb-1">💾 Backup Your Data</Text>
              <Text className="text-xs text-muted">
                Regularly export your data to ensure you don't lose your reading history.
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
