import React, { useState } from 'react';
import {
  View,
  Text,
  Pressable,
  Modal,
  Image,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { pickImageFromCamera, pickImageFromLibrary, PickedImage } from '@/lib/image-picker';
import { useColors } from '@/hooks/use-colors';

interface ImagePickerModalProps {
  visible: boolean;
  onClose: () => void;
  onImageSelected: (image: PickedImage) => void;
  currentImageUri?: string;
}

export function ImagePickerModal({
  visible,
  onClose,
  onImageSelected,
  currentImageUri,
}: ImagePickerModalProps) {
  const colors = useColors();
  const [loading, setLoading] = useState(false);

  const handlePickFromCamera = async () => {
    setLoading(true);
    try {
      const image = await pickImageFromCamera();
      if (image) {
        onImageSelected(image);
        onClose();
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to pick image from camera');
      console.error('Camera error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handlePickFromLibrary = async () => {
    setLoading(true);
    try {
      const image = await pickImageFromLibrary();
      if (image) {
        onImageSelected(image);
        onClose();
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to pick image from library');
      console.error('Library error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent={false}
      onRequestClose={onClose}
    >
      <View className="flex-1 bg-background">
        {/* Header */}
        <View className="bg-surface border-b border-border px-4 py-3 pt-4">
          <View className="flex-row justify-between items-center">
            <Text className="text-xl font-bold text-foreground">Select Cover Image</Text>
            <Pressable
              onPress={onClose}
              style={({ pressed }) => [{ opacity: pressed ? 0.6 : 1 }]}
            >
              <Text className="text-base font-medium text-primary">Cancel</Text>
            </Pressable>
          </View>
        </View>

        {/* Content */}
        <View className="flex-1 px-4 py-6 items-center justify-center gap-4">
          {/* Current Image Preview */}
          {currentImageUri && (
            <View className="mb-4">
              <Text className="text-sm text-muted mb-2 text-center">Current Cover</Text>
              <Image
                source={{ uri: currentImageUri }}
                style={{ width: 120, height: 180, borderRadius: 8 }}
              />
            </View>
          )}

          {/* Loading Indicator */}
          {loading && (
            <View className="items-center gap-2">
              <ActivityIndicator size="large" color={colors.primary} />
              <Text className="text-sm text-muted">Loading image...</Text>
            </View>
          )}

          {/* Buttons */}
          {!loading && (
            <View className="w-full gap-3">
              <Pressable
                onPress={handlePickFromCamera}
                style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
              >
                <View className="bg-primary rounded-lg py-4 items-center">
                  <Text className="text-base font-semibold text-background">📷 Take Photo</Text>
                </View>
              </Pressable>

              <Pressable
                onPress={handlePickFromLibrary}
                style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
              >
                <View className="bg-surface border border-border rounded-lg py-4 items-center">
                  <Text className="text-base font-semibold text-foreground">
                    🖼️ Choose from Library
                  </Text>
                </View>
              </Pressable>
            </View>
          )}

          {/* Info Text */}
          <View className="mt-6 px-4">
            <Text className="text-xs text-muted text-center leading-relaxed">
              Choose a cover image for your book. The image will be cropped to a 2:3 aspect ratio
              (standard book cover dimensions).
            </Text>
          </View>
        </View>
      </View>
    </Modal>
  );
}
