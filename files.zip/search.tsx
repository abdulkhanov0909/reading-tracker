import React, { useState, useMemo } from 'react';
import { ScrollView, Text, View, TextInput, Pressable, FlatList } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { useBooks } from '@/lib/book-context';
import { BookCard } from '@/components/book-card';
import { BookDetailModal } from '@/components/book-detail-modal';
import { Book } from '@/lib/storage';
import { useColors } from '@/hooks/use-colors';

type SortOption = 'title' | 'author' | 'date-added' | 'progress';
type StatusFilter = 'all' | 'want-to-read' | 'reading' | 'completed';

export default function SearchScreen() {
  const colors = useColors();
  const { books, notes, updateBook, deleteBook, addNote, deleteNote, getNotes } = useBooks();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [sortBy, setSortBy] = useState<SortOption>('title');
  const [selectedBook, setSelectedBook] = useState<Book | null>(null);

  const filteredAndSortedBooks = useMemo(() => {
    let filtered = books;

    // Apply status filter
    if (statusFilter !== 'all') {
      filtered = filtered.filter((b) => b.status === statusFilter);
    }

    // Apply search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        (b) =>
          b.title.toLowerCase().includes(query) ||
          b.author.toLowerCase().includes(query)
      );
    }

    // Apply sorting
    const sorted = [...filtered];
    switch (sortBy) {
      case 'title':
        sorted.sort((a, b) => a.title.localeCompare(b.title));
        break;
      case 'author':
        sorted.sort((a, b) => a.author.localeCompare(b.author));
        break;
      case 'date-added':
        sorted.sort((a, b) => b.createdAt - a.createdAt);
        break;
      case 'progress':
        sorted.sort((a, b) => {
          const progressA = a.totalPages > 0 ? a.currentPage / a.totalPages : 0;
          const progressB = b.totalPages > 0 ? b.currentPage / b.totalPages : 0;
          return progressB - progressA;
        });
        break;
    }

    return sorted;
  }, [books, searchQuery, statusFilter, sortBy]);

  const handleMarkCompleted = async (bookId: string) => {
    await updateBook(bookId, {
      status: 'completed',
      completedDate: Date.now(),
      currentPage: books.find((b) => b.id === bookId)?.totalPages || 0,
    });
  };

  const handleUpdateProgress = async (currentPage: number) => {
    if (selectedBook) {
      await updateBook(selectedBook.id, { currentPage });
      const updated = books.find((b) => b.id === selectedBook.id);
      if (updated) {
        setSelectedBook(updated);
      }
    }
  };

  const handleMarkCompletedFromDetail = async () => {
    if (selectedBook) {
      await updateBook(selectedBook.id, {
        status: 'completed',
        completedDate: Date.now(),
        currentPage: selectedBook.totalPages,
      });
      setSelectedBook(null);
    }
  };

  const handleDeleteBook = async () => {
    if (selectedBook) {
      await deleteBook(selectedBook.id);
      setSelectedBook(null);
    }
  };

  const handleAddNote = async (text: string) => {
    if (selectedBook) {
      await addNote(selectedBook.id, text);
    }
  };

  const handleDeleteNote = async (noteId: string) => {
    await deleteNote(noteId);
  };

  return (
    <>
      <ScreenContainer className="p-0">
        {/* Header */}
        <View className="bg-surface border-b border-border px-4 py-3">
          <Text className="text-2xl font-bold text-foreground">Search Books</Text>
        </View>

        {/* Search Bar */}
        <View className="bg-surface border-b border-border px-4 py-3">
          <TextInput
            placeholder="Search by title or author..."
            placeholderTextColor={colors.muted}
            value={searchQuery}
            onChangeText={setSearchQuery}
            className="bg-background border border-border rounded-lg px-3 py-2 text-foreground"
          />
        </View>

        {/* Filters */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          className="bg-surface border-b border-border px-4 py-3"
          contentContainerStyle={{ gap: 8 }}
        >
          {/* Status Filter */}
          <View>
            <Text className="text-xs text-muted mb-1 font-medium">Status:</Text>
            <View className="flex-row gap-2">
              {(['all', 'want-to-read', 'reading', 'completed'] as const).map((status) => (
                <Pressable
                  key={status}
                  onPress={() => setStatusFilter(status)}
                  style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
                >
                  <View
                    className="px-3 py-1 rounded-full border"
                    style={{
                      backgroundColor:
                        statusFilter === status ? `${colors.primary}20` : 'transparent',
                      borderColor: statusFilter === status ? colors.primary : colors.border,
                    }}
                  >
                    <Text
                      className="text-xs font-medium"
                      style={{
                        color: statusFilter === status ? colors.primary : colors.muted,
                      }}
                    >
                      {status === 'all'
                        ? 'All'
                        : status === 'want-to-read'
                          ? 'Want'
                          : status === 'reading'
                            ? 'Reading'
                            : 'Done'}
                    </Text>
                  </View>
                </Pressable>
              ))}
            </View>
          </View>

          {/* Sort Option */}
          <View>
            <Text className="text-xs text-muted mb-1 font-medium">Sort:</Text>
            <View className="flex-row gap-2">
              {(['title', 'author', 'date-added', 'progress'] as const).map((sort) => (
                <Pressable
                  key={sort}
                  onPress={() => setSortBy(sort)}
                  style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
                >
                  <View
                    className="px-3 py-1 rounded-full border"
                    style={{
                      backgroundColor:
                        sortBy === sort ? `${colors.primary}20` : 'transparent',
                      borderColor: sortBy === sort ? colors.primary : colors.border,
                    }}
                  >
                    <Text
                      className="text-xs font-medium"
                      style={{
                        color: sortBy === sort ? colors.primary : colors.muted,
                      }}
                    >
                      {sort === 'title'
                        ? 'Title'
                        : sort === 'author'
                          ? 'Author'
                          : sort === 'date-added'
                            ? 'New'
                            : 'Progress'}
                    </Text>
                  </View>
                </Pressable>
              ))}
            </View>
          </View>
        </ScrollView>

        {/* Results */}
        {filteredAndSortedBooks.length === 0 ? (
          <ScrollView
            className="flex-1 px-4"
            contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', alignItems: 'center' }}
          >
            <Text className="text-base text-muted text-center">
              {searchQuery || statusFilter !== 'all'
                ? 'No books match your search'
                : 'No books in your library'}
            </Text>
          </ScrollView>
        ) : (
          <ScrollView className="flex-1 px-4 py-4">
            <View>
              <Text className="text-sm text-muted mb-3">
                {filteredAndSortedBooks.length} book{filteredAndSortedBooks.length !== 1 ? 's' : ''}
              </Text>
              {filteredAndSortedBooks.map((book) => (
                <BookCard
                  key={book.id}
                  book={book}
                  onPress={() => setSelectedBook(book)}
                  onMarkCompleted={() => handleMarkCompleted(book.id)}
                />
              ))}
            </View>
          </ScrollView>
        )}
      </ScreenContainer>

      {/* Detail Modal */}
      {selectedBook && (
        <BookDetailModal
          visible={!!selectedBook}
          book={selectedBook}
          notes={getNotes(selectedBook.id)}
          onClose={() => setSelectedBook(null)}
          onUpdateProgress={handleUpdateProgress}
          onMarkCompleted={handleMarkCompletedFromDetail}
          onDeleteBook={handleDeleteBook}
          onAddNote={handleAddNote}
          onDeleteNote={handleDeleteNote}
        />
      )}
    </>
  );
}
