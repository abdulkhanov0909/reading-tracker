import React from 'react';
import { View, Text, Pressable, Image } from 'react-native';
import { Book } from '@/lib/storage';
import { useColors } from '@/hooks/use-colors';
import { cn } from '@/lib/utils';

interface BookCardProps {
  book: Book;
  onPress: () => void;
  onMarkCompleted?: () => void;
}

export function BookCard({ book, onPress, onMarkCompleted }: BookCardProps) {
  const colors = useColors();

  const statusColor = {
    'want-to-read': colors.muted,
    'reading': colors.warning,
    'completed': colors.success,
  }[book.status];

  const statusLabel = {
    'want-to-read': 'Want to Read',
    'reading': 'Reading',
    'completed': 'Completed',
  }[book.status];

  const progressPercent = book.totalPages > 0 ? (book.currentPage / book.totalPages) * 100 : 0;

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        {
          opacity: pressed ? 0.7 : 1,
        },
      ]}
    >
      <View className="bg-surface rounded-lg p-3 mb-3 border border-border flex-row gap-3">
        {/* Cover Image */}
        {book.coverImageUri ? (
          <Image
            source={{ uri: book.coverImageUri }}
            style={{
              width: 60,
              height: 90,
              borderRadius: 6,
              backgroundColor: colors.border,
            }}
          />
        ) : (
          <View
            className="rounded-md items-center justify-center bg-border"
            style={{
              width: 60,
              height: 90,
            }}
          >
            <Text className="text-2xl">📖</Text>
          </View>
        )}

        {/* Content */}
        <View className="flex-1">
          {/* Header with title and status */}
          <View className="mb-2">
            <Text className="text-base font-semibold text-foreground" numberOfLines={2}>
              {book.title}
            </Text>
            <Text className="text-sm text-muted mt-1" numberOfLines={1}>
              {book.author}
            </Text>
          </View>

          {/* Status badge */}
          <View className="mb-2">
            <View
              className="px-2 py-1 rounded-full self-start"
              style={{ backgroundColor: `${statusColor}20` }}
            >
              <Text className="text-xs font-medium" style={{ color: statusColor }}>
                {statusLabel}
              </Text>
            </View>
          </View>

          {/* Progress bar for reading books */}
          {book.status === 'reading' && (
            <View className="mb-2">
              <View className="flex-row items-center justify-between mb-1">
                <Text className="text-xs text-muted">
                  {book.currentPage} / {book.totalPages} pages
                </Text>
                <Text className="text-xs text-muted font-medium">
                  {Math.round(progressPercent)}%
                </Text>
              </View>
              <View className="h-1.5 bg-border rounded-full overflow-hidden">
                <View
                  className="h-full bg-primary rounded-full"
                  style={{ width: `${progressPercent}%` }}
                />
              </View>
            </View>
          )}

          {/* Completed date for completed books */}
          {book.status === 'completed' && book.completedDate && (
            <View className="mb-2">
              <Text className="text-xs text-muted">
                Completed {new Date(book.completedDate).toLocaleDateString()}
              </Text>
            </View>
          )}

          {/* Quick action button for reading books */}
          {book.status === 'reading' && onMarkCompleted && (
            <Pressable
              onPress={(e) => {
                e.stopPropagation?.();
                onMarkCompleted();
              }}
              style={({ pressed }) => [
                {
                  opacity: pressed ? 0.7 : 1,
                },
              ]}
            >
              <View className="bg-primary/10 py-1.5 rounded px-2 items-center">
                <Text className="text-xs font-medium text-primary">Mark Completed</Text>
              </View>
            </Pressable>
          )}
        </View>
      </View>
    </Pressable>
  );
}
