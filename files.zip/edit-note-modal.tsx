import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  Pressable,
  Modal,
  TextInput,
  Alert,
} from 'react-native';
import { Note } from '@/lib/storage';
import { useColors } from '@/hooks/use-colors';

interface EditNoteModalProps {
  visible: boolean;
  note: Note | null;
  onClose: () => void;
  onSave: (noteId: string, newText: string) => Promise<void>;
}

export function EditNoteModal({ visible, note, onClose, onSave }: EditNoteModalProps) {
  const colors = useColors();
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (note) {
      setText(note.text);
    }
  }, [note]);

  if (!note) return null;

  const handleSave = async () => {
    if (!text.trim()) {
      Alert.alert('Error', 'Note cannot be empty');
      return;
    }

    setLoading(true);
    try {
      await onSave(note.id, text.trim());
      onClose();
    } catch (error) {
      Alert.alert('Error', 'Failed to save note');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal visible={visible} animationType="fade" transparent onRequestClose={onClose}>
      <View className="flex-1 bg-black/50 justify-center items-center px-4">
        <View className="bg-surface rounded-xl w-full max-w-md border border-border overflow-hidden">
          {/* Header */}
          <View className="border-b border-border px-4 py-3">
            <View className="flex-row justify-between items-center">
              <Text className="text-lg font-bold text-foreground">Edit Note</Text>
              <Pressable onPress={onClose} style={({ pressed }) => [{ opacity: pressed ? 0.6 : 1 }]}>
                <Text className="text-sm font-medium text-primary">Cancel</Text>
              </Pressable>
            </View>
          </View>

          {/* Content */}
          <View className="p-4">
            <TextInput
              placeholder="Edit your note..."
              placeholderTextColor={colors.muted}
              value={text}
              onChangeText={setText}
              multiline
              editable={!loading}
              className="bg-background border border-border rounded-lg px-3 py-3 text-foreground mb-4"
              style={{ minHeight: 120, textAlignVertical: 'top' }}
              autoFocus
            />

            <View className="flex-row gap-2">
              <Pressable
                onPress={onClose}
                className="flex-1"
                style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
              >
                <View className="bg-border py-3 rounded-lg items-center">
                  <Text className="text-sm font-medium text-foreground">Cancel</Text>
                </View>
              </Pressable>

              <Pressable
                onPress={handleSave}
                disabled={loading || !text.trim()}
                className="flex-1"
                style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
              >
                <View
                  className="py-3 rounded-lg items-center"
                  style={{
                    backgroundColor: loading || !text.trim() ? `${colors.primary}50` : colors.primary,
                  }}
                >
                  <Text className="text-sm font-medium text-background">
                    {loading ? 'Saving...' : 'Save'}
                  </Text>
                </View>
              </Pressable>
            </View>
          </View>
        </View>
      </View>
    </Modal>
  );
}
