# Reading Tracker — Project TODO

## Core Features

### Library Screen
- [x] Display books in list/grid view
- [x] Show reading status badges (Want to Read, Reading, Completed)
- [x] Group books by reading status
- [x] Pull-to-refresh functionality
- [x] Empty state with CTA to add first book
- [x] Quick actions (mark completed, favorite)

### Add Book Screen
- [x] Form with title, author, ISBN, pages, status, dates
- [ ] Cover image picker (camera/gallery)
- [x] Input validation with error messages
- [x] Save book to local storage
- [x] Cancel button to return to Library

### Book Detail Screen
- [x] Display full book information
- [x] Show progress bar and current page / total pages
- [x] Display reading stats (start date, target date, pages today)
- [x] Notes section with list of personal notes
- [x] Add note functionality
- [x] Edit note functionality
- [x] Delete note functionality
- [x] Mark book as completed
- [x] Edit book information
- [x] Delete book with confirmation
- [ ] Share book details

### Search Screen
- [x] Search bar with real-time filtering
- [x] Filter by reading status
- [x] Sort options (title, author, date added, progress)
- [x] Display search results
- [x] Tap result to open Detail screen

### Settings Screen
- [x] Theme toggle (Light/Dark/System)
- [ ] Display preference (List/Grid view)
- [x] Data export to JSON
- [x] Data import from JSON backup
- [x] About app information

## Data Management

- [x] Local storage setup with AsyncStorage
- [x] Book data model with schema
- [x] Notes data model with timestamps
- [x] Data persistence across app sessions
- [x] Data export/import functionality

## UI/UX Polish

- [x] Custom app icon and branding
- [x] Color scheme implementation (warm literary palette)
- [ ] Haptic feedback on key interactions
- [ ] Smooth screen transitions
- [x] Loading states and indicators
- [x] Error handling and user feedback
- [x] Empty states for all screens

## Navigation

- [x] Tab bar with Library, Search, Settings tabs
- [x] Tab bar icon mapping
- [x] Modal screens for Add Book and Book Detail
- [x] Proper back navigation

## Testing

- [ ] Test add book flow end-to-end
- [ ] Test progress tracking updates
- [ ] Test note creation and management
- [ ] Test search and filtering
- [ ] Test data persistence
- [ ] Test theme switching


## Enhancement Features

### Reading Statistics Dashboard
- [ ] Create statistics screen with reading metrics
- [ ] Calculate total books read
- [ ] Calculate average pages per day
- [ ] Track reading streaks
- [ ] Display reading goals and progress
- [ ] Add charts/visualizations for reading trends

### Book Cover Image Upload
- [ ] Add image picker to Add Book modal
- [ ] Integrate camera/gallery functionality
- [ ] Store cover images locally
- [ ] Display cover images in book cards
- [ ] Handle image compression and optimization
- [ ] Add image preview before saving

### Reading Reminders and Notifications
- [ ] Create notification preferences in Settings
- [ ] Implement daily reading reminders
- [ ] Add completion alerts for books near finish
- [ ] Set up background notification scheduling
- [ ] Allow users to customize reminder times
- [ ] Track notification engagement
