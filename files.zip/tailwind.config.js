/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,jsx,ts,tsx}",
    "./components/**/*.{js,jsx,ts,tsx}"
  ],
  theme: {
    extend: {
      colors: {
        primary: '#8B4513',
        'primary-dark': '#D2691E',
        background: '#FAFAF8',
        'background-dark': '#1A1A18',
        surface: '#FFFFFF',
        'surface-dark': '#2A2A28',
        foreground: '#2C2C2C',
        'foreground-dark': '#F5F5F3',
        muted: '#8A8A86',
        'muted-dark': '#A0A09C',
        border: '#E8E8E4',
        'border-dark': '#3A3A38',
        success: '#4CAF50',
        'success-dark': '#66BB6A',
        warning: '#FF9800',
        'warning-dark': '#FFB74D',
        error: '#F44336',
        'error-dark': '#EF5350',
      },
    },
  },
  plugins: [],
}
