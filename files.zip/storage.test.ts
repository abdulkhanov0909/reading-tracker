import { describe, it, expect, beforeEach, vi } from 'vitest';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { storage, Book, Note } from '../storage';

// Mock AsyncStorage
vi.mock('@react-native-async-storage/async-storage', () => ({
  default: {
    getItem: vi.fn(),
    setItem: vi.fn(),
    removeItem: vi.fn(),
  },
}));

describe('Storage Service', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('Books Operations', () => {
    it('should get empty array when no books exist', async () => {
      vi.mocked(AsyncStorage.getItem).mockResolvedValue(null);
      const books = await storage.getBooks();
      expect(books).toEqual([]);
    });

    it('should add a new book', async () => {
      vi.mocked(AsyncStorage.getItem).mockResolvedValue(null);
      vi.mocked(AsyncStorage.setItem).mockResolvedValue(undefined);

      const newBook = await storage.addBook({
        title: 'Test Book',
        author: 'Test Author',
        totalPages: 300,
        currentPage: 0,
        status: 'reading',
      });

      expect(newBook).toBeDefined();
      expect(newBook.title).toBe('Test Book');
      expect(newBook.author).toBe('Test Author');
      expect(newBook.totalPages).toBe(300);
      expect(newBook.id).toBeDefined();
      expect(newBook.createdAt).toBeDefined();
      expect(newBook.updatedAt).toBeDefined();
      expect(vi.mocked(AsyncStorage.setItem)).toHaveBeenCalled();
    });

    it('should update a book', async () => {
      const existingBook: Book = {
        id: 'book_1',
        title: 'Original Title',
        author: 'Test Author',
        totalPages: 300,
        currentPage: 50,
        status: 'reading',
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };

      vi.mocked(AsyncStorage.getItem).mockResolvedValue(JSON.stringify([existingBook]));
      vi.mocked(AsyncStorage.setItem).mockResolvedValue(undefined);

      const updated = await storage.updateBook('book_1', {
        currentPage: 100,
      });

      expect(updated).toBeDefined();
      expect(updated?.currentPage).toBe(100);
      expect(updated?.title).toBe('Original Title');
      expect(vi.mocked(AsyncStorage.setItem)).toHaveBeenCalled();
    });

    it('should delete a book', async () => {
      const existingBook: Book = {
        id: 'book_1',
        title: 'Test Book',
        author: 'Test Author',
        totalPages: 300,
        currentPage: 0,
        status: 'reading',
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };

      vi.mocked(AsyncStorage.getItem).mockResolvedValue(JSON.stringify([existingBook]));
      vi.mocked(AsyncStorage.setItem).mockResolvedValue(undefined);

      const deleted = await storage.deleteBook('book_1');

      expect(deleted).toBe(true);
      expect(vi.mocked(AsyncStorage.setItem)).toHaveBeenCalled();
    });

    it('should get a book by id', async () => {
      const existingBook: Book = {
        id: 'book_1',
        title: 'Test Book',
        author: 'Test Author',
        totalPages: 300,
        currentPage: 0,
        status: 'reading',
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };

      vi.mocked(AsyncStorage.getItem).mockResolvedValue(JSON.stringify([existingBook]));

      const book = await storage.getBook('book_1');

      expect(book).toEqual(existingBook);
    });
  });

  describe('Notes Operations', () => {
    it('should get empty array when no notes exist', async () => {
      vi.mocked(AsyncStorage.getItem).mockResolvedValue(null);
      const notes = await storage.getNotes('book_1');
      expect(notes).toEqual([]);
    });

    it('should add a note to a book', async () => {
      vi.mocked(AsyncStorage.getItem).mockResolvedValue(null);
      vi.mocked(AsyncStorage.setItem).mockResolvedValue(undefined);

      const newNote = await storage.addNote('book_1', 'Great book!');

      expect(newNote).toBeDefined();
      expect(newNote.text).toBe('Great book!');
      expect(newNote.bookId).toBe('book_1');
      expect(newNote.id).toBeDefined();
      expect(newNote.createdAt).toBeDefined();
      expect(vi.mocked(AsyncStorage.setItem)).toHaveBeenCalled();
    });

    it('should delete a note', async () => {
      const existingNote: Note = {
        id: 'note_1',
        bookId: 'book_1',
        text: 'Test note',
        createdAt: Date.now(),
      };

      vi.mocked(AsyncStorage.getItem).mockResolvedValue(JSON.stringify([existingNote]));
      vi.mocked(AsyncStorage.setItem).mockResolvedValue(undefined);

      const deleted = await storage.deleteNote('note_1');

      expect(deleted).toBe(true);
      expect(vi.mocked(AsyncStorage.setItem)).toHaveBeenCalled();
    });
  });

  describe('Export/Import', () => {
    it('should export data', async () => {
      const mockBook: Book = {
        id: 'book_1',
        title: 'Test Book',
        author: 'Test Author',
        totalPages: 300,
        currentPage: 0,
        status: 'reading',
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };

      const mockNote: Note = {
        id: 'note_1',
        bookId: 'book_1',
        text: 'Test note',
        createdAt: Date.now(),
      };

      vi.mocked(AsyncStorage.getItem)
        .mockResolvedValueOnce(JSON.stringify([mockBook]))
        .mockResolvedValueOnce(JSON.stringify([mockNote]));

      const exported = await storage.exportData();

      expect(exported.books).toEqual([mockBook]);
      expect(exported.notes).toEqual([mockNote]);
    });

    it('should import data', async () => {
      const mockBook: Book = {
        id: 'book_1',
        title: 'Test Book',
        author: 'Test Author',
        totalPages: 300,
        currentPage: 0,
        status: 'reading',
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };

      const mockNote: Note = {
        id: 'note_1',
        bookId: 'book_1',
        text: 'Test note',
        createdAt: Date.now(),
      };

      vi.mocked(AsyncStorage.setItem).mockResolvedValue(undefined);

      await storage.importData({
        books: [mockBook],
        notes: [mockNote],
      });

      expect(vi.mocked(AsyncStorage.setItem)).toHaveBeenCalledTimes(2);
    });
  });
});
