import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  Pressable,
  ScrollView,
  Modal,
  TextInput,
  Alert,
} from 'react-native';
import { Book } from '@/lib/storage';
import { useColors } from '@/hooks/use-colors';
import { ImagePickerModal } from '@/components/image-picker-modal';

interface EditBookModalProps {
  visible: boolean;
  book: Book | null;
  onClose: () => void;
  onSave: (bookId: string, updates: Partial<Book>) => Promise<void>;
}

export function EditBookModal({ visible, book, onClose, onSave }: EditBookModalProps) {
  const colors = useColors();
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [isbn, setIsbn] = useState('');
  const [totalPages, setTotalPages] = useState('');
  const [currentPage, setCurrentPage] = useState('');
  const [status, setStatus] = useState<'want-to-read' | 'reading' | 'completed'>('want-to-read');
  const [startDate, setStartDate] = useState<number | null>(null);
  const [targetDate, setTargetDate] = useState<number | null>(null);
  const [coverImage, setCoverImage] = useState<string | null>(null);
  const [showImagePicker, setShowImagePicker] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (book) {
      setTitle(book.title);
      setAuthor(book.author);
      setIsbn(book.isbn || '');
      setTotalPages(book.totalPages.toString());
      setCurrentPage(book.currentPage.toString());
      setStatus(book.status);
      setStartDate(book.startDate || null);
      setTargetDate(book.targetDate || null);
      setCoverImage(book.coverImage || null);
    }
  }, [book]);

  if (!book) return null;

  const handleSave = async () => {
    if (!title.trim() || !author.trim()) {
      Alert.alert('Error', 'Title and Author are required');
      return;
    }

    const pages = parseInt(totalPages);
    const current = parseInt(currentPage);

    if (isNaN(pages) || pages <= 0) {
      Alert.alert('Error', 'Please enter a valid number of pages');
      return;
    }

    if (isNaN(current) || current < 0 || current > pages) {
      Alert.alert('Error', `Current page must be between 0 and ${pages}`);
      return;
    }

    setLoading(true);
    try {
      await onSave(book.id, {
        title: title.trim(),
        author: author.trim(),
        isbn: isbn.trim() || undefined,
        totalPages: pages,
        currentPage: current,
        status,
        startDate,
        targetDate,
        coverImage,
      });
      onClose();
    } catch (error) {
      Alert.alert('Error', 'Failed to save changes');
    } finally {
      setLoading(false);
    }
  };

  const statusOptions: Array<{ value: Book['status']; label: string; color: string }> = [
    { value: 'want-to-read', label: 'Want to Read', color: colors.muted },
    { value: 'reading', label: 'Reading', color: colors.warning },
    { value: 'completed', label: 'Completed', color: colors.success },
  ];

  return (
    <>
      <Modal visible={visible} animationType="slide" transparent={false} onRequestClose={onClose}>
        <View className="flex-1 bg-background">
          {/* Header */}
          <View className="bg-surface border-b border-border px-4 py-3 pt-4">
            <View className="flex-row justify-between items-center">
              <Pressable onPress={onClose} style={({ pressed }) => [{ opacity: pressed ? 0.6 : 1 }]}>
                <Text className="text-base font-medium text-primary">Cancel</Text>
              </Pressable>
              <Text className="text-xl font-bold text-foreground">Edit Book</Text>
              <Pressable
                onPress={handleSave}
                disabled={loading}
                style={({ pressed }) => [{ opacity: pressed ? 0.6 : 1 }]}
              >
                <Text
                  className="text-base font-semibold"
                  style={{ color: loading ? colors.muted : colors.primary }}
                >
                  Save
                </Text>
              </Pressable>
            </View>
          </View>

          {/* Content */}
          <ScrollView className="flex-1 px-4 py-4">
            {/* Cover Image */}
            <View className="mb-4">
              <Text className="text-sm font-medium text-foreground mb-2">Cover Image (Optional)</Text>
              <Pressable
                onPress={() => setShowImagePicker(true)}
                style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
              >
                <View
                  className="bg-surface border border-border rounded-lg overflow-hidden"
                  style={{ height: 200 }}
                >
                  {coverImage ? (
                    <View className="flex-1 items-center justify-center bg-primary/5">
                      <Text className="text-primary font-medium">📷 Cover Image Set</Text>
                      <Text className="text-xs text-muted mt-1">Tap to change</Text>
                    </View>
                  ) : (
                    <View className="flex-1 items-center justify-center">
                      <Text className="text-4xl mb-2">📚</Text>
                      <Text className="text-sm font-medium text-muted">Tap to add cover</Text>
                    </View>
                  )}
                </View>
              </Pressable>
            </View>

            {/* Title */}
            <View className="mb-4">
              <Text className="text-sm font-medium text-foreground mb-2">
                Title <Text className="text-error">*</Text>
              </Text>
              <TextInput
                placeholder="Book title"
                placeholderTextColor={colors.muted}
                value={title}
                onChangeText={setTitle}
                className="bg-surface border border-border rounded-lg px-3 py-3 text-foreground"
              />
            </View>

            {/* Author */}
            <View className="mb-4">
              <Text className="text-sm font-medium text-foreground mb-2">
                Author <Text className="text-error">*</Text>
              </Text>
              <TextInput
                placeholder="Author name"
                placeholderTextColor={colors.muted}
                value={author}
                onChangeText={setAuthor}
                className="bg-surface border border-border rounded-lg px-3 py-3 text-foreground"
              />
            </View>

            {/* ISBN */}
            <View className="mb-4">
              <Text className="text-sm font-medium text-foreground mb-2">ISBN (Optional)</Text>
              <TextInput
                placeholder="978-..."
                placeholderTextColor={colors.muted}
                value={isbn}
                onChangeText={setIsbn}
                className="bg-surface border border-border rounded-lg px-3 py-3 text-foreground"
              />
            </View>

            {/* Pages */}
            <View className="flex-row gap-3 mb-4">
              <View className="flex-1">
                <Text className="text-sm font-medium text-foreground mb-2">
                  Total Pages <Text className="text-error">*</Text>
                </Text>
                <TextInput
                  placeholder="300"
                  placeholderTextColor={colors.muted}
                  value={totalPages}
                  onChangeText={setTotalPages}
                  keyboardType="number-pad"
                  className="bg-surface border border-border rounded-lg px-3 py-3 text-foreground"
                />
              </View>

              <View className="flex-1">
                <Text className="text-sm font-medium text-foreground mb-2">Current Page</Text>
                <TextInput
                  placeholder="0"
                  placeholderTextColor={colors.muted}
                  value={currentPage}
                  onChangeText={setCurrentPage}
                  keyboardType="number-pad"
                  className="bg-surface border border-border rounded-lg px-3 py-3 text-foreground"
                />
              </View>
            </View>

            {/* Reading Status */}
            <View className="mb-4">
              <Text className="text-sm font-medium text-foreground mb-2">Reading Status</Text>
              <View className="flex-row gap-2">
                {statusOptions.map((option) => (
                  <Pressable
                    key={option.value}
                    onPress={() => setStatus(option.value)}
                    style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
                    className="flex-1"
                  >
                    <View
                      className="py-2 px-3 rounded-lg border"
                      style={{
                        backgroundColor: status === option.value ? `${option.color}20` : 'transparent',
                        borderColor: status === option.value ? option.color : colors.border,
                      }}
                    >
                      <Text
                        className="text-xs font-medium text-center"
                        style={{
                          color: status === option.value ? option.color : colors.foreground,
                        }}
                      >
                        {option.label}
                      </Text>
                    </View>
                  </Pressable>
                ))}
              </View>
            </View>

            {/* Dates Info */}
            {startDate && (
              <View className="mb-4 bg-surface border border-border rounded-lg p-3">
                <Text className="text-xs text-muted mb-1">Started Reading</Text>
                <Text className="text-sm text-foreground">
                  {new Date(startDate).toLocaleDateString()}
                </Text>
              </View>
            )}

            {targetDate && (
              <View className="mb-4 bg-surface border border-border rounded-lg p-3">
                <Text className="text-xs text-muted mb-1">Target Completion</Text>
                <Text className="text-sm text-foreground">
                  {new Date(targetDate).toLocaleDateString()}
                </Text>
              </View>
            )}
          </ScrollView>
        </View>
      </Modal>

      {/* Image Picker Modal */}
      <ImagePickerModal
        visible={showImagePicker}
        onClose={() => setShowImagePicker(false)}
        onImageSelected={(uri) => {
          setCoverImage(uri);
          setShowImagePicker(false);
        }}
      />
    </>
  );
}
