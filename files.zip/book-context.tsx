import React, { createContext, useContext, useReducer, useEffect, useCallback } from 'react';
import { storage, Book, Note } from './storage';

interface BookContextType {
  books: Book[];
  notes: Map<string, Note[]>;
  loading: boolean;
  addBook: (book: Omit<Book, 'id' | 'createdAt' | 'updatedAt'>) => Promise<Book>;
  updateBook: (id: string, updates: Partial<Book>) => Promise<Book | null>;
  deleteBook: (id: string) => Promise<boolean>;
  addNote: (bookId: string, text: string) => Promise<Note>;
  updateNote: (noteId: string, text: string) => Promise<Note | null>;
  deleteNote: (noteId: string) => Promise<boolean>;
  getNotes: (bookId: string) => Note[];
  refreshBooks: () => Promise<void>;
}

const BookContext = createContext<BookContextType | undefined>(undefined);

type BookAction =
  | { type: 'SET_BOOKS'; payload: Book[] }
  | { type: 'ADD_BOOK'; payload: Book }
  | { type: 'UPDATE_BOOK'; payload: Book }
  | { type: 'DELETE_BOOK'; payload: string }
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_NOTES'; payload: Map<string, Note[]> };

interface BookState {
  books: Book[];
  notes: Map<string, Note[]>;
  loading: boolean;
}

function bookReducer(state: BookState, action: BookAction): BookState {
  switch (action.type) {
    case 'SET_BOOKS':
      return { ...state, books: action.payload };
    case 'ADD_BOOK':
      return { ...state, books: [...state.books, action.payload] };
    case 'UPDATE_BOOK':
      return {
        ...state,
        books: state.books.map((b) => (b.id === action.payload.id ? action.payload : b)),
      };
    case 'DELETE_BOOK':
      return { ...state, books: state.books.filter((b) => b.id !== action.payload) };
    case 'SET_LOADING':
      return { ...state, loading: action.payload };
    case 'SET_NOTES':
      return { ...state, notes: action.payload };
    default:
      return state;
  }
}

export function BookProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(bookReducer, {
    books: [],
    notes: new Map(),
    loading: true,
  });

  // Load initial data
  useEffect(() => {
    loadInitialData();
  }, []);

  const loadInitialData = async () => {
    dispatch({ type: 'SET_LOADING', payload: true });
    try {
      const books = await storage.getBooks();
      dispatch({ type: 'SET_BOOKS', payload: books });

      // Load notes for all books
      const notesMap = new Map<string, Note[]>();
      for (const book of books) {
        const bookNotes = await storage.getNotes(book.id);
        notesMap.set(book.id, bookNotes);
      }
      dispatch({ type: 'SET_NOTES', payload: notesMap });
    } catch (error) {
      console.error('Error loading initial data:', error);
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  };

  const refreshBooks = useCallback(async () => {
    await loadInitialData();
  }, []);

  const addBook = useCallback(async (book: Omit<Book, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newBook = await storage.addBook(book);
    dispatch({ type: 'ADD_BOOK', payload: newBook });
    dispatch({
      type: 'SET_NOTES',
      payload: new Map(state.notes).set(newBook.id, []),
    });
    return newBook;
  }, [state.notes]);

  const updateBook = useCallback(async (id: string, updates: Partial<Book>) => {
    const updated = await storage.updateBook(id, updates);
    if (updated) {
      dispatch({ type: 'UPDATE_BOOK', payload: updated });
    }
    return updated;
  }, []);

  const deleteBook = useCallback(async (id: string) => {
    const success = await storage.deleteBook(id);
    if (success) {
      dispatch({ type: 'DELETE_BOOK', payload: id });
      const newNotes = new Map(state.notes);
      newNotes.delete(id);
      dispatch({ type: 'SET_NOTES', payload: newNotes });
    }
    return success;
  }, [state.notes]);

  const addNote = useCallback(async (bookId: string, text: string) => {
    const newNote = await storage.addNote(bookId, text);
    const bookNotes = state.notes.get(bookId) || [];
    const newNotes = new Map(state.notes);
    newNotes.set(bookId, [...bookNotes, newNote]);
    dispatch({ type: 'SET_NOTES', payload: newNotes });
    return newNote;
  }, [state.notes]);

  const updateNote = useCallback(async (noteId: string, text: string) => {
    const updated = await storage.updateNote(noteId, text);
    if (updated) {
      const bookNotes = state.notes.get(updated.bookId) || [];
      const newNotes = new Map(state.notes);
      newNotes.set(
        updated.bookId,
        bookNotes.map((n) => (n.id === noteId ? updated : n))
      );
      dispatch({ type: 'SET_NOTES', payload: newNotes });
    }
    return updated;
  }, [state.notes]);

  const deleteNote = useCallback(async (noteId: string) => {
    const success = await storage.deleteNote(noteId);
    if (success) {
      const newNotes = new Map(state.notes);
      for (const [bookId, notes] of newNotes.entries()) {
        const filtered = notes.filter((n) => n.id !== noteId);
        if (filtered.length !== notes.length) {
          newNotes.set(bookId, filtered);
          break;
        }
      }
      dispatch({ type: 'SET_NOTES', payload: newNotes });
    }
    return success;
  }, [state.notes]);

  const getNotes = useCallback(
    (bookId: string) => {
      return state.notes.get(bookId) || [];
    },
    [state.notes]
  );

  const value: BookContextType = {
    books: state.books,
    notes: state.notes,
    loading: state.loading,
    addBook,
    updateBook,
    deleteBook,
    addNote,
    updateNote,
    deleteNote,
    getNotes,
    refreshBooks,
  };

  return <BookContext.Provider value={value}>{children}</BookContext.Provider>;
}

export function useBooks() {
  const context = useContext(BookContext);
  if (!context) {
    throw new Error('useBooks must be used within a BookProvider');
  }
  return context;
}
