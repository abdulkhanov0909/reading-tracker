import React, { useState } from 'react';
import { ScrollView, Text, View, Pressable, FlatList, RefreshControl, ActivityIndicator } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { useBooks } from '@/lib/book-context';
import { BookCard } from '@/components/book-card';
import { AddBookModal } from '@/components/add-book-modal';
import { BookDetailModal } from '@/components/book-detail-modal';
import { Book } from '@/lib/storage';
import { useColors } from '@/hooks/use-colors';

export default function HomeScreen() {
  const colors = useColors();
  const { books, notes, loading, addBook, updateBook, deleteBook, addNote, deleteNote, updateNote, refreshBooks, getNotes } = useBooks();
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedBook, setSelectedBook] = useState<Book | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  const handleRefresh = async () => {
    setRefreshing(true);
    await refreshBooks();
    setRefreshing(false);
  };

  const handleMarkCompleted = async (bookId: string) => {
    await updateBook(bookId, {
      status: 'completed',
      completedDate: Date.now(),
      currentPage: books.find((b) => b.id === bookId)?.totalPages || 0,
    });
  };

  const handleUpdateProgress = async (currentPage: number) => {
    if (selectedBook) {
      await updateBook(selectedBook.id, { currentPage });
      const updated = books.find((b) => b.id === selectedBook.id);
      if (updated) {
        setSelectedBook(updated);
      }
    }
  };

  const handleMarkCompletedFromDetail = async () => {
    if (selectedBook) {
      await updateBook(selectedBook.id, {
        status: 'completed',
        completedDate: Date.now(),
        currentPage: selectedBook.totalPages,
      });
      setSelectedBook(null);
    }
  };

  const handleDeleteBook = async () => {
    if (selectedBook) {
      await deleteBook(selectedBook.id);
      setSelectedBook(null);
    }
  };

  const handleAddNote = async (text: string) => {
    if (selectedBook) {
      await addNote(selectedBook.id, text);
    }
  };

  const handleDeleteNote = async (noteId: string) => {
    await deleteNote(noteId);
  };

  const handleUpdateBook = async (bookId: string, updates: Partial<Book>) => {
    await updateBook(bookId, updates);
    const updated = books.find((b) => b.id === bookId);
    if (updated) {
      setSelectedBook(updated);
    }
  };

  const handleUpdateNote = async (noteId: string, text: string) => {
    await updateNote(noteId, text);
  };

  // Group books by status
  const wantToRead = books.filter((b) => b.status === 'want-to-read');
  const reading = books.filter((b) => b.status === 'reading');
  const completed = books.filter((b) => b.status === 'completed');

  if (loading) {
    return (
      <ScreenContainer className="items-center justify-center">
        <ActivityIndicator size="large" color={colors.primary} />
      </ScreenContainer>
    );
  }

  return (
    <>
      <ScreenContainer className="p-0">
        {/* Header */}
        <View className="bg-surface border-b border-border px-4 py-3">
          <View className="flex-row justify-between items-center">
            <Text className="text-2xl font-bold text-foreground">Reading Tracker</Text>
            <Pressable
              onPress={() => setShowAddModal(true)}
              style={({ pressed }) => [{ opacity: pressed ? 0.6 : 1 }]}
            >
              <View className="bg-primary rounded-full w-10 h-10 items-center justify-center">
                <Text className="text-lg font-bold text-background">+</Text>
              </View>
            </Pressable>
          </View>
        </View>

        {/* Content */}
        {books.length === 0 ? (
          <ScrollView
            className="flex-1 px-4"
            contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', alignItems: 'center' }}
          >
            <Text className="text-lg font-semibold text-foreground mb-2">No Books Yet</Text>
            <Text className="text-sm text-muted text-center mb-4">
              Start building your library by adding your first book.
            </Text>
            <Pressable
              onPress={() => setShowAddModal(true)}
              style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
            >
              <View className="bg-primary px-6 py-3 rounded-lg">
                <Text className="text-base font-semibold text-background">Add First Book</Text>
              </View>
            </Pressable>
          </ScrollView>
        ) : (
          <ScrollView
            className="flex-1 px-4 py-4"
            refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}
          >
            {/* Reading Section */}
            {reading.length > 0 && (
              <View className="mb-6">
                <Text className="text-lg font-bold text-foreground mb-3">Currently Reading</Text>
                {reading.map((book) => (
                  <BookCard
                    key={book.id}
                    book={book}
                    onPress={() => setSelectedBook(book)}
                    onMarkCompleted={() => handleMarkCompleted(book.id)}
                  />
                ))}
              </View>
            )}

            {/* Want to Read Section */}
            {wantToRead.length > 0 && (
              <View className="mb-6">
                <Text className="text-lg font-bold text-foreground mb-3">Want to Read</Text>
                {wantToRead.map((book) => (
                  <BookCard
                    key={book.id}
                    book={book}
                    onPress={() => setSelectedBook(book)}
                  />
                ))}
              </View>
            )}

            {/* Completed Section */}
            {completed.length > 0 && (
              <View className="mb-6">
                <Text className="text-lg font-bold text-foreground mb-3">Completed</Text>
                {completed.map((book) => (
                  <BookCard
                    key={book.id}
                    book={book}
                    onPress={() => setSelectedBook(book)}
                  />
                ))}
              </View>
            )}
          </ScrollView>
        )}
      </ScreenContainer>

      {/* Modals */}
      <AddBookModal
        visible={showAddModal}
        onClose={() => setShowAddModal(false)}
        onAdd={async (book) => {
          await addBook(book);
        }}
      />

      {selectedBook && (
        <BookDetailModal
          visible={!!selectedBook}
          book={selectedBook}
          notes={getNotes(selectedBook.id)}
          onClose={() => setSelectedBook(null)}
          onUpdateProgress={handleUpdateProgress}
          onMarkCompleted={handleMarkCompletedFromDetail}
          onDeleteBook={handleDeleteBook}
          onAddNote={handleAddNote}
          onDeleteNote={handleDeleteNote}
          onUpdateBook={handleUpdateBook}
          onUpdateNote={handleUpdateNote}
        />
      )}
    </>
  );
}
